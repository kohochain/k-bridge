import intl from 'react-intl-universal';
import en from '../locales/en';
import zh from '../locales/zh';
import jp from '../locales/ja';
import ko from '../locales/ko';

// locale data
const locales = {
    en,
    zh,
    jp,
    ko,
};

export default currentLocale => intl.init({
    currentLocale,
    locales,
});
