import React, { Component } from "react";
import { Modal, Toast} from 'antd-mobile';
import intl from "react-intl-universal";
import {
    getETHAddress,
    getKHCAddress,
    getTRXAddress,
    getBSCAddress,
    getBitKeepKHC,
    getBitKeepETH, getBitKeepTRX, getBitKeepBSC
} from "../../../utils/getAddress";
import {addressHidden} from "../../../utils/kidHidden";

const imgs = {
    'hd':require('../../../images/bridge/hd.png'),
    'chrome':require('../../../images/bridge/chrome.png'),
    'khc':require('../../../images/bridge/k-wallet.png'),
    'bit-keep':require('../../../images/bridge/bit-keep.png'),
    'back':require('../../../images/bridge/back.png'),
    'khc-address':require('../../../images/bridge/khc-address.png'),
    'eth-address':require('../../../images/bridge/eth-address.png'),
    'bsc-address':require('../../../images/bridge/bsc-address.png'),
    'trx-address':require('../../../images/bridge/trx-address.png'),
    'refresh':require('../../../images/bridge/refresh.png'),
}

const prefix = 'bridge-toast';

class ModalWalletChoose extends Component {

    constructor(props){
        super(props);
        this.state = {
            tab:0, //0初始，1 Khc钱包， 2 BitKeep钱包， 3 Chrome插件
        }
    }

    async check(type) //2 Bitkeep钱包， 3 Chrome插件
    {

        if(type === 3)
        {
            const khc = getKHCAddress();
            this.setState({khc:khc});

            if(window.ethereum)
            {
                window.ethereum.request({method:'eth_requestAccounts'}).then((res)=>{
                    getETHAddress().then((eth)=>{
                        if(eth){
                            this.setState({eth:eth});
                        }
                        else {
                            this.setState({eth:null});
                        }
                    });
                });
            }

            const trx = getTRXAddress();
            this.setState({trx:trx});

            const bsc = await getBSCAddress();
            if(bsc){
                this.setState({bsc:bsc});
            }
            else {
                this.setState({bsc:null});
            }

            if(khc === null)
            {
                setTimeout(()=>{
                    this.check(type);
                }, 2000)
            }
        }
        else if (type === 2){
            const khc = getBitKeepKHC();
            this.setState({khc:khc});

            const eth = getBitKeepETH();
            this.setState({eth:eth});

            const trx = getBitKeepTRX();
            this.setState({trx:trx});

            const bsc = getBitKeepBSC();
            this.setState({bsc:bsc});
        }
    }

    renderConfig(){

        const { visible, onClose} = this.props;

        return (
            <div className={`flex-display-col`} style={{padding:'8vw 5.33vw'}}>
                <div className={`${prefix}-title`} style={{fontWeight:'bold', marginBottom:'4vw'}}>服务正在初始化</div>
                <div className={`${prefix}-title`} style={{fontSize:'3.47vw'}}>请选择您的访问环境状态</div>
                {/*<div onClick={()=>{*/}
                {/*    this.setState({tab:2});*/}
                {/*    this.check(2);*/}
                {/*}} className={`${prefix}-card`}>*/}
                {/*    <div style={{padding:'5.33vw'}}>*/}
                {/*        <div className={'flex-display'} style={{marginBottom:'4vw'}}>*/}
                {/*            <div className={`${prefix}-p1`}>*/}
                {/*                我是HD钱包*/}
                {/*            </div>*/}
                {/*            <img src={imgs.hd} alt='' style={{width:'13.33vw', height:'5.87vw', marginLeft:'2.67vw'}} />*/}
                {/*        </div>*/}
                {/*        <div className={`${prefix}-p2`} style={{textAlign:'left'}}>*/}
                {/*            HD钱包指使用一个私钥，管理多个区块链网络的钱包。如：bitkeep、imtoken*/}
                {/*        </div>*/}
                {/*    </div>*/}
                {/*</div>*/}
                <div onClick={()=>{
                    this.setState({tab:1});
                    onClose(1);
                }} className={`${prefix}-card`} style={{marginTop:'4vw'}}>
                    <div className={'flex-display'} style={{padding:'4vw 5.33vw'}}>
                        <div className={`${prefix}-p1`} style={{textAlign:'left'}}>
                            {intl.get('TEXT_20')}
                        </div>
                        <div>
                            <img className={`${prefix}-icon2`} style={{width:'9.07vw', height:'9.07vw'}} src={imgs.khc} alt=''/>
                            <img className={`${prefix}-icon2`} style={{width:'9.07vw', height:'9.07vw'}} src={imgs['bit-keep']} alt=''/>
                        </div>
                    </div>
                </div>
                <div onClick={()=>{
                    this.setState({tab:3});
                    this.check(3);
                }} className={`${prefix}-card`} style={{marginTop:'4vw'}}>
                    <div className={'flex-display'} style={{padding:'5.33vw'}}>
                        <div className={`${prefix}-p1`} style={{textAlign:'left'}}>
                            {intl.get('TEXT_21')}
                        </div>
                        <img className={`${prefix}-icon2`} src={imgs.chrome} alt=''/>
                    </div>
                </div>
            </div>
        )
    }

    renderAddressCell(url, address){

        return (
            <div className={'flex-display'} style={{marginBottom:'4vw'}}>
                <img className={`${prefix}-icon-address`} src={url} alt='' />
                <div className={`${prefix}-p1`} style={{fontWeight:'normal'}}>
                    {addressHidden(address)}
                </div>
            </div>
        )
    }

    renderExtensionCell(url, address, flag){
        return (
            <div className={'flex-between'} style={{marginBottom:'4vw', width:'100%'}}>
                <div className={'flex-display'}>
                    <img className={`${prefix}-icon-address`} src={url} alt='' />
                    {flag ? <div>
                        <div className={`${prefix}-p4`} style={{fontWeight:'normal', textAlign:'left'}}>
                            {intl.get('TEXT_22')}
                        </div>
                        <div className={`${prefix}-p1`} style={{fontWeight:'normal', textAlign:'left'}}>
                            {addressHidden(address)}
                        </div>
                    </div> : <div>
                        <div className={`${prefix}-p3`} style={{fontWeight:'normal', textAlign:'left'}}>
                            {intl.get('TEXT_23')}
                        </div>
                        <div className={`${prefix}-p1`} style={{fontWeight:'normal'}}>
                            {intl.get('TEXT_24')}
                        </div>
                    </div>}
                </div>
                <div onClick={()=>{this.check(3)}} className={`${prefix}-refresh flex-center`}>
                    <img className={`${prefix}-refresh-icon`} src={imgs['refresh']}/>
                </div>
            </div>
        )
    }

    renderChooseAddress(){

        const {onClose} = this.props;
        const {khc, trx, eth, bsc, tab} = this.state;
        const disable = !khc;

        return (
            <div className={'relative'} style={{padding:'8vw 5.33vw'}}>
                <img onClick={()=>{
                    this.setState({tab:0})
                }} className={`${prefix}-back`} src={imgs.back} alt='' />
                <div className={`${prefix}-title`} style={{fontWeight:'bold', marginBottom:'4vw'}}>{intl.get('TEXT_27')}</div>
                <div className={'flex-display-col'} style={{alignItems: 'flex-start'}}>
                    {this.renderAddressCell(imgs['khc-address'], khc)}
                    {this.renderAddressCell(imgs['eth-address'], eth)}
                    {this.renderAddressCell(imgs['bsc-address'], bsc)}
                    {this.renderAddressCell(imgs['trx-address'], trx)}
                    <div className={`${prefix}-get flex-display`} style={{marginTop:'1.33vw'}}>
                        <div className={`${prefix}-get-p`}>
                            {intl.get('TEXT_25')}
                        </div>
                    </div>
                </div>
                <div onClick={disable ? ()=>{}:()=>{onClose(tab, {khcAddress:khc, ethAddress:eth, bscAddress:bsc, trxAddress:trx})}} className={disable ? 'bridge-btn bridge-disable flex-center' : 'bridge-btn flex-center'} style={{width:'73.33vw', marginTop:'5.33vw'}}>
                    <div className={'bridge-btn-p'}>
                        GO
                    </div>
                </div>
            </div>
        )
    }

    renderChrome(){

        const {onClose} = this.props;
        const {khc, trx, eth, bsc, tab} = this.state;
        const disable = !khc;

        return (
            <div className={'relative'} style={{padding:'8vw 5.33vw'}}>
                <img onClick={()=>{
                    this.setState({tab:0})
                }} className={`${prefix}-back`} src={imgs.back} alt='' />
                <div className={`${prefix}-title`} style={{fontWeight:'bold', marginBottom:'4vw'}}>{intl.get('TEXT_28')}</div>
                <div className={'flex-display-col'} style={{alignItems: 'flex-start'}}>
                    {this.renderExtensionCell(imgs['khc-address'], khc, !!khc)}
                    {this.renderExtensionCell(imgs['eth-address'], eth, !!eth)}
                    {this.renderExtensionCell(imgs['bsc-address'], bsc, !!bsc)}
                    {this.renderExtensionCell(imgs['trx-address'], trx, !!trx)}
                    <div className={`${prefix}-get flex-display`} style={{marginTop:'1.33vw'}}>
                        <div className={`${prefix}-get-p`} style={{textAlign:'left'}}>
                            {intl.get('TEXT_26')}
                        </div>
                    </div>
                    <div className={`${prefix}-get flex-display`} style={{marginTop:'2.67vw', width:'auto'}}>
                        <div className={`${prefix}-get-p`}>
                            {intl.get('TEXT_25')}
                        </div>
                    </div>
                </div>
                <div onClick={disable ? ()=>{}:()=>{onClose(tab, {khcAddress:khc, ethAddress:eth, bscAddress:bsc, trxAddress:trx})}} className={disable ? 'bridge-btn bridge-disable flex-center' : 'bridge-btn flex-center'} style={{width:'73.33vw', marginTop:'5.33vw'}}>
                    <div className={'bridge-btn-p'}>
                        GO
                    </div>
                </div>
            </div>
        )
    }

    render() {
        const { visible, onClose} = this.props;
        const {tab} = this.state;
        let content = this.renderConfig();

        switch (tab) {
            case 0:
                content = this.renderConfig();
                break;
            case 2:
                content = this.renderChooseAddress();
                break;
            case 3:
                content = this.renderChrome();
                break;
        }

        return (
            <Modal
                popup
                visible={visible}
                // onClose={()=>{onClose()}}
                // animationType="slide-up"
                // afterClose={() => { onClose() }}
            >
                <div className={'flex-center-col'} style={{width:'100vw', height:'100vh', backgroundColor:'rgba(60, 68, 76, 0.3)'}}>
                    <div className={`${prefix}`}>
                        <div className={`${prefix}-bg`}>
                            {content}
                        </div>
                    </div>
                </div>

            </Modal>
        );
    }
}

export default ModalWalletChoose;
