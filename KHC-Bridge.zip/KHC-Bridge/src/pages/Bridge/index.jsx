import React, { Component } from "react";
import {Modal, Toast, Switch, Carousel, Popover} from 'antd-mobile';
import intl from "react-intl-universal";
import net from "../../server";
import connect from "../../store/connect";
import moment from "moment";
import {inuputCheck, extensionErr} from "../../lib";
import {
    signTimestamp,
    getM20BalanceResult,
    getK20Contract,
    getExchangeContract,
    getETHContract,
    getBSCContract,
    getRC20Contract,
    initWeb3,
    getERC20Contract,
    getTRC20Contract,
    getTRXContract,
    checkTrxHash,
    getTrxApproveResult,
    getRC20Balance,
    getERC20Balance, getTRC20Balance
} from "../../utils/mdc";
import Input from "../Swap/components/Input";
import ModalSearch from "./Modal/ModalSearch";
import ModalSelect from "./Modal/ModalSelect";
import BigNumber from "bignumber.js";
import ModalQRcode from "./Modal/ModalQRcode";
import WAValidator from 'wallet-address-validator'
import ModalSuccess from "./Modal/ModalSuccess";
import ModalFail from "./Modal/ModalFail";
import kidHidden from "../../utils/kidHidden";
import setLanguage from "../setLanguage";
import ModalWalletChoose from "./Modal/ModalWalletChoose";
import {
    getBitKeepBSC,
    getBitKeepETH,
    getBitKeepKHC,
    getBitKeepTRX,
    getBSCAddress,
    getETHAddress, getKHCAddress, getTRXAddress
} from "../../utils/getAddress";
import {fromDecimals, getRound, toDecimals} from "../../utils/checkValue";
import Web from "./Web";

const Item = Popover.Item;

const imgs = {
    'exchange':require('../../images/bridge/exchange.png'),
    'ETH':require('../../images/bridge/chain-ETH.png'),
    'BSC':require('../../images/bridge/chain-BSC.png'),
    'VDS':require('../../images/bridge/chain-VDS.png'),
    'TRON':require('../../images/bridge/chain-TRX.png'),
    'arrow-bottom':require('../../images/bridge/arrow-bottom.png'),
    'USDT':require('../../images/bridge/USDT.png'),
    'UNI':require('../../images/bridge/UNI.png'),
    'KHC':require('../../images/bridge/chain-KHC.png'),
    'khc-address':require('../../images/bridge/khc-address.png'),
    'eth-address':require('../../images/bridge/eth-address.png'),
    'bsc-address':require('../../images/bridge/bsc-address.png'),
    'trx-address':require('../../images/bridge/trx-address.png'),
    'vds-address':require('../../images/bridge/vds-address.png'),
    'ready':require('../../images/bridge/wallet-ready.png'),
};

const eth_khc_address = process.env.REACT_APP_ETH_KHC_ADDRESS;
const bsc_khc_address = process.env.REACT_APP_BSC_KHC_ADDRESS;
const trx_khc_address = process.env.REACT_APP_TRX_KHC_ADDRESS;
const exchangeContract = process.env.REACT_APP_EXCHANGE_ADDRESS;

class Index extends Component {

    constructor(props){
        super(props);
        this.state = {
            leftAsset:'ETH',
            rightAsset:'KHC',
            assets:[],
            original:[],
            searchKey:'',
            selectAsset:'ETH',
            addressArray:[],
            amount:'',
            amountErr:'',
            address:'',
            addressErr:'',
            lang:localStorage.getItem('lang') || 'zh',
            env:0, //1 KHC钱包环境， 2 bitkeep环境， 3 chrome环境
        }
    }

    componentDidMount() {
        // this.login();

        this.setState({checkVisible:true});
    }

    checkEnv(env, obj){
        this.setState({env:env});
        if(obj){
            this.setState(obj);
            if(obj.khcAddress)
            {
                this.setState({address:obj.khcAddress});
            }
        }

        const {address} = this.props.redux;
        localStorage.setItem('address', address);
        this.getConfig();
    }

    async login() {
        const {address} = this.props.redux;

        Toast.loading(intl.get('WAITING'), 0);

        if (address) {

            localStorage.setItem('address', address);
            this.getConfig();

            // const web3 = await win


            // console.log('window.__bitkeepAccount', window.__bitkeepAccount);
            console.log('window.web3', window.web3);
            console.log('window.ethereum', window.ethereum); //ethereum.networkVersion === 56 || 1
            // console.log('window.tronWeb', window.tronWeb);
            // console.log('window.BinanceChain', window);

            // const bsc = await window.BinanceChain.requestAddresses();

            // console.log('window.bsc', bsc[2]); //以太坊地址


        } else {
            setTimeout(() => this.login(), 3000)
        }
    }

    getConfig(){
        net.getExchangeConfig().then(res => {
            Toast.hide();
            if(res.response_code === '00' )
            {
                let assets = [];
                // let originAssets = JSON.parse(JSON.stringify(res.content));

                res.content.map((item, index) => {

                    let same = false;

                    for (let i = 0; i < assets.length; i++){
                        let tmpItem = assets[i];
                        if(item.asset === tmpItem.asset)
                        {
                            tmpItem.chains.push(item.block_chain);
                            tmpItem.types.push(item.type);
                            tmpItem.contracts.push(item.contract_address);
                            tmpItem.minFees.push(item.min_fee);
                            same = true;
                            break;
                        }
                    }

                    if(!same){
                        item.chains = [];
                        item.types = [];
                        item.contracts = [];
                        item.minFees = [];
                        // item.depositFees = [];
                        item.chains.push(item.block_chain);
                        item.types.push(item.type);
                        item.contracts.push(item.contract_address);
                        item.minFees.push(item.min_fee);
                        // item.depositFees.push(item.depositFee);
                        assets.push(item);
                    }
                });

                this.setState({assets:assets, original:res.content}, ()=>{
                    this.updateBalance();
                });
            }
            else {
                Toast.fail(res.response_msg);
            }
        });
    }

    async getAddress(){

        Toast.loading(intl.get('WAITING'), 0);

        const params = await signTimestamp();

        net.getExchangeAddress(params).then(res => {
            Toast.hide();
            if(res.response_code === '00')
            {
                this.setState({addressArray:res.content}, ()=>{
                    this.setState({qrcodeVisible:true});
                });
            }
            else {
                Toast.fail(res.response_msg);
            }
        });
    }

    checkInput(val){
        let value = inuputCheck(val,  4);
        if (value[value.length - 1] === '.' || value[value.length - 1] === '0') {
        } else {
            value = value ? Number(value) : '';
        }

        this.setState({amount:value});

        const {currentBalance} = this.state;
        const fee = this.getFee();

        if(value > currentBalance)
        {
            this.setState({amountErr:intl.get('BALANCE_NOT_ENOUGH')});
            return;
        }

        if(value <= fee) {
            this.setState({amountErr:intl.get('FEE_NOT_ENOUGH')})
        } else {
            this.setState({amountErr:''})
        }
    }

    getChains(){

        const array = [{image:imgs['ETH'], chain:'KHC', chainName: 'KHC'},
            {image:imgs['TRX'], chain:'TRON', chainName: 'TRX'},
            {image:imgs['ETH'],  chain:'ETH', chainName: 'ETH'},
            {image:imgs['VDS'], chain:'VDS', chainName:'VDS'}];

        let result = [];

        const {selectedIndex, searchAssets} = this.state;

        if(!searchAssets.length)
        {
            return result;
        }

        let asset = searchAssets[selectedIndex];

        array.map((item, index)=>{
            let flag = asset.chains.find(chain => {
                return item.chain === chain;
            });

            if(flag){
                result.push(item);
            }
        })

        return result;
    }

    getSelectChainName(asset){
        const {selectAsset} = this.state;

        if(asset === 'KHC')
        {
            return 'KH20';
        }
        else {
            return  this.getChainType(selectAsset);
        }
    }

    getChainName(asset){

        const {leftAsset} = this.state;

        switch (asset){
            case 'ETH':
                return 'Ether';
            case 'KHC':
                return 'Koho';
            case 'USDT':
                if(leftAsset === 'TRON')
                {
                    return 'TRC20';
                }
                return 'RC20';
            case 'VDS':
                return 'Vollar';
            default:
                return 'ERC20';
        }
    }

    getChainType(asset){

        const {assets, rightAsset} = this.state;

        if(!assets.length || asset === '') {
            return '';
        }

        let result = assets.find(item => {

            if(item.asset === asset)
            {
                return item;
            }
        });

        for(let i = 0; i < result.chains.length; i++)
        {
            if(rightAsset === result.chains[i]) {

                if(result.types[i] === 'BASE')
                {
                    return result.asset;
                }

                if(result.types[i] === 'KHC20') {
                    return 'KHC20';
                }

                return result.types[i];
            }
        }

        return '';
    }

    getDecimals(){
        const {original, leftAsset, selectAsset} = this.state;

        if(!original.length || leftAsset === '') {
            return 0;
        }

        console.log('leftAsset', leftAsset)

        let result = original.find(item => {
            if(item.asset === selectAsset && item.block_chain === leftAsset)
            {
                return item;
            }
        });

        return result.decimals;
    }

    toDecimals(amount){
        const decimals = this.getDecimals();

        console.log('decimals', toDecimals(amount, decimals));

        return toDecimals(amount, decimals);
    }

    getMainChains(){

        const asset = this.getCurrentAssetObj();

        return asset.chains || [];


        // return ['ETH', 'TRON', 'VDS', 'KHC'];
    }

    getCurrentChain(){
        // const obj = this.getCurrentAssetObj();

        const {leftAsset} = this.state;

        return leftAsset;
    }

    SelectAsset(asset, right){

        const {leftAsset, rightAsset} = this.state;

        if(right){

            if (asset === rightAsset)
            {

            }
            else if(asset === 'KHC')
            {
                this.setState({rightAsset:asset, leftAsset:rightAsset}, ()=>{this.checkErr();})
            }
            else {
                this.setState({rightAsset:asset, leftAsset:'KHC'}, ()=>{
                    this.checkErr();
                });
            }
        } else {

            if (asset === leftAsset)
            {

            }
            else if(asset === 'KHC')
            {
                this.setState({rightAsset:leftAsset, leftAsset:asset}, ()=>{this.checkErr();})
            }
            else {
                this.setState({rightAsset:'KHC', leftAsset:asset}, ()=>{
                    this.checkErr();
                });
            }
        }
    }

    onSelect(val){
        this.setState({selectAsset:val, searchVisible:false}, ()=>{
            const {leftAsset} = this.state;

            const asset = this.getCurrentAssetObj();
            let newAsset = '';
            asset.chains.map((item)=> {
                if(item !== 'KHC')
                {
                    newAsset = item;
                }
            });

            if(leftAsset !== 'KHC')
            {
                this.setState({leftAsset:newAsset}, ()=>{this.checkErr();})
            }
            else {
                this.setState({rightAsset:newAsset}, ()=>{this.checkErr();})
            }
        });
    }

    reverse(){
        const {leftAsset, rightAsset} = this.state;

        if(leftAsset === 'KHC'){
            this.setState({leftAsset:rightAsset, rightAsset:'KHC'}, ()=>{
                // this.changeSelectAsset();
                this.checkErr();
            });
        }
        else {
            this.setState({rightAsset:leftAsset, leftAsset:'KHC'}, ()=>{
                // this.changeSelectAsset();
                this.checkErr();
            });
        }
    }

    getCurrentAssetObj(){
        const {selectAsset, assets} = this.state;
        // const assets = this.getCurrentAssets();

        let result = {};

        if(assets.length)
        {
            assets.map((item)=> {
                if(item.asset === selectAsset)
                {
                    result = item;
                }
            })
        }

        return result;
    }

    getSearchAssets(){
        const {assets} = this.state;

        return assets;
    }

    isDeposit() {
        const {rightAsset} = this.state;

        if(rightAsset === 'KHC')
        {
            return true;
        }
        else {
            return false;
        }
    }

    getFee(){

        const assetObj = this.getCurrentAssetObj();
        const isDeposit = this.isDeposit();

        let depositFee = 0;
        let minFee = 0;
        const flag = JSON.stringify(assetObj) === '{}';

        if(!flag)
        {
            minFee = assetObj.min_fee;
            depositFee = assetObj.deposit_fee || 0;
        }

        const fee = isDeposit ? (flag ? '-': depositFee):(flag ? '-': minFee);

        return fee;
    }

    btnClick(){
        const {env} = this.state;
        const inputFlag = this.getInputFlag();
        const isDeposit = this.isDeposit();

        if(inputFlag)
        {
            this.getAddress();
        }
        else {
            switch (env)
            {
                case 1:
                    this.withdraw();
                    break;
                case 2:
                    if(isDeposit)
                    {
                        this.deposit();
                    }
                    else {
                        this.withdraw();
                    }
                    break;
                case 3:
                    if(isDeposit)
                    {
                        this.deposit();
                    }
                    else {
                        this.withdraw();
                    }
                    break;
            }
        }
    }

    async withdraw(){

        const {kht} = this.props.redux.balance;
        const {amount, selectAsset} = this.state;

        if(kht === 0)
        {
            this.setState({failVisible:true, message:intl.get('TEXT_10')});
            return;
        }

        if(selectAsset === 'KHC')
        {
            if(Number(kht) < Number(amount))
            {
                this.setState({failVisible:true, message:intl.get('TEXT_9', {selectAsset:selectAsset})});
                return;
            }

            Toast.loading(intl.get('WAITING'), 0);

            this.withdrawKHC()

            return;
        }

        const balance = await getM20BalanceResult(this.getM20ContractAddress());

        if(Number(balance) < Number(amount))
        {
            this.setState({failVisible:true, message:intl.get('TEXT_9', {selectAsset:selectAsset})});
            return;
        }

        Toast.loading(intl.get('WAITING'), 0);

        let functions = await getK20Contract(this.getM20ContractAddress());

        functions.approve(exchangeContract, window.KHCExtension.toKoho(amount)).send().then(res => {
            this.getApproveResult(res);
        }).catch(
            res => {
                let err = extensionErr(res);
                Toast.fail(err, 2, () => {
                }, false);
            });
    }

    getApproveResult(res) {
        console.log('result.ret ------->', res);
        window.KHCExtension.khc.getTransaction(res).then(result => {
            if (!result.ret) {
                setTimeout(() => {
                    this.getApproveResult(res)
                }, 2000);
                return;
            }
            console.log('result.ret ------->', result);

            if (result.ret && result.ret[0]['contractRet'] === 'SUCCESS') {
                this.withdrawM20();
            } else {
                Toast.fail(intl.get('APPROVE_FAIL'), 2)
            }
        }).catch(()=>{
            this.getApproveResult(res);
        })
    }

    deposit(){
        const {selectAsset} = this.state;
        const chain = this.getCurrentChain();

        if(chain === 'ETH')
        {
            if(selectAsset === 'ETH')
            {
                this.depositEth();
            }
            else {
                this.approveERC20();
            }
        }
        else if (chain === 'BSC') {
            this.approveERC20();
        }
        else if (chain === 'TRON') {
            this.approveTRC20()
        }

    }

    getContractAddress(){
        const {leftAsset} = this.state;
        switch (leftAsset)
        {
            case 'ETH':
                return eth_khc_address;
            case 'BSC':
                return bsc_khc_address;
            case 'TRON':
                return trx_khc_address;
        }
    }

    async fromAddress(){
        const {env} = this.state;
        const chain = this.getCurrentChain();
        const {address} = this.props.redux;
        switch (env){
            case 0:
                return '';
            case 1:
                return address;
            case 2:
                if(chain === 'ETH')
                {
                    return getBitKeepETH();
                }
                else if(chain === 'BSC')
                {
                    return getBitKeepBSC();
                }
                else if(chain === 'TRON')
                {
                    return getBitKeepTRX();
                }
                else {
                    return getBitKeepKHC();
                }
            case 3:
                if(chain === 'ETH')
                {
                    return await getETHAddress();
                }
                else if(chain === 'BSC')
                {
                    return await getBSCAddress();
                }
                else if(chain === 'TRON')
                {
                    return getTRXAddress();
                }
                else {
                    return getKHCAddress();
                }
            default:
                return '';
        }
    }

    async depositEth(){

        const myContract = this.state.leftAsset === 'ETH' ? await getETHContract(eth_khc_address) : await getBSCContract(bsc_khc_address);
        const web3 = await initWeb3();
        const {amount, address} = this.state;

        Toast.loading(intl.get('WAITING'), 0);

        const fromAddress = await this.fromAddress();

        myContract.methods.exchangeOtherBaseTokenToKHC(address).send({from:fromAddress, value:web3.utils.toWei(amount.toString()) }).then(res => {
            console.log('res', res);
            Toast.hide();
            this.setState({successVisible:true});
        }).catch(e => {
            console.log('e', e);
            Toast.fail(intl.get('CONTRACT_FAIL'), 2)
        })
    }

    async approveERC20()
    {
        const {amount} = this.state;
        const myContract = this.state.leftAsset === 'ETH' ? await getERC20Contract(this.getDestContractAddress(this.state.leftAsset)) : await getRC20Contract(this.getDestContractAddress(this.state.leftAsset))

        Toast.loading(intl.get('WAITING'), 0);

        const fromAddress = await this.fromAddress();
        const contract_address = this.getContractAddress();

        myContract.methods.approve(contract_address, this.toDecimals(amount)).send({from:fromAddress}).then(res => {
            console.log('approve', res);
            Toast.hide();
            this.depositERC20();
        }).catch(e => {
            console.log('e', e);
            Toast.fail(intl.get('CONTRACT_FAIL'), 2)
        })
    }

    async depositERC20(){
        const contract_address = this.getContractAddress();
        const myContract = this.state.leftAsset === 'ETH' ? await getETHContract(contract_address) : await getBSCContract(contract_address);
        const {amount, address} = this.state;

        Toast.loading(intl.get('WAITING'), 0);

        const fromAddress = await this.fromAddress();

        myContract.methods.exchangeOther20ChainToKHC(this.toDecimals(amount), address, this.getDestContractAddress(this.state.leftAsset)).send({from:fromAddress}).then(res => {
            console.log('res', res);
            Toast.hide();
            this.setState({successVisible:true});
        }).catch(e => {
            console.log('e', e);
            Toast.fail(intl.get('CONTRACT_FAIL'), 2)
        })
    }

    async approveTRC20(){
        const {amount} = this.state;
        const obj = this.getCurrentAssetObj();
        const contract = await getTRC20Contract(this.getDestContractAddress(this.state.leftAsset));
        const contract_address = this.getContractAddress();

        Toast.loading(intl.get('WAITING'), 0);

        contract.approve(contract_address, this.toDecimals(amount).toNumber()).send().then(res => {
            console.log('approve', res);
            getTrxApproveResult(res, ()=>{
                this.depositTRC20();
            })
        }).catch(e => {
            console.log('e', e);
            Toast.fail(intl.get('CONTRACT_FAIL'), 2)
        })
    }

    async depositTRC20(){
        const contract_address = this.getContractAddress();
        const myContract = await getTRXContract(contract_address);
        const {amount, address} = this.state;
        const obj = this.getCurrentAssetObj();

        Toast.loading(intl.get('WAITING'), 0);

        myContract.exchangeOther20ChainToKHC(this.toDecimals(amount).toNumber(), address, this.getDestContractAddress(this.state.leftAsset)).send().then(res => {
            getTrxApproveResult(res, ()=>{
                Toast.hide();
                this.setState({successVisible:true});
            })
        }).catch(e => {
            console.log('e', e);
            Toast.fail(intl.get('CONTRACT_FAIL'), 2)
        })
    }

    async withdrawM20(){

        const {amount, address, rightAsset, selectAsset} = this.state;

        const contract = await getExchangeContract();

        if(selectAsset === 'ETH')
        {
            contract.depositEth(window.KHCExtension.toKoho(amount), address).send().then(res => {
                console.log('res', res);
                if (res) {
                    this.checkHash(res);
                } else {
                    Toast.fail(intl.get('CONTRACT_FAIL'), 2)
                }
            }).catch(
                res => {
                    console.log('error = ', res);
                    Toast.fail(intl.get('CONTRACT_FAIL'), 2)
                });
        }
        else if (selectAsset === 'USDT')
        {
            if(rightAsset === 'TRON'){

                contract.depositUsdt(window.KHCExtension.toKoho(amount), address).send().then(res => {
                    console.log('res', res);
                    if (res) {
                        this.checkHash(res);
                    } else {
                        Toast.fail(intl.get('CONTRACT_FAIL'), 2)
                    }
                }).catch(
                    res => {
                        console.log('error = ', res);
                        Toast.fail(intl.get('CONTRACT_FAIL'), 2)
                    });
            }
            else {
                contract.exchangeM20ToOtherChain(window.KHCExtension.toKoho(amount), address, this.getM20ContractAddress(), this.getDestContractAddress()).send().then(res => {
                    console.log('res', res);
                    if (res) {
                        this.checkHash(res);
                    } else {
                        Toast.fail(intl.get('CONTRACT_FAIL'), 2)
                    }
                }).catch(
                    res => {
                        console.log('error = ', res);
                        Toast.fail(intl.get('CONTRACT_FAIL'), 2)
                    });
            }
        }
        else {
            contract.depositM20(window.KHCExtension.toKoho(amount), address, this.getM20ContractAddress()).send().then(res => {
                console.log('res', res);
                if (res) {
                    this.checkHash(res);
                } else {
                    Toast.fail(intl.get('CONTRACT_FAIL'), 2)
                }
            }).catch(
                res => {
                    console.log('error = ', res);
                    Toast.fail(intl.get('CONTRACT_FAIL'), 2)
                });
        }
    }

    async withdrawKHC(){
        const {amount, address, rightAsset, selectAsset} = this.state;

        const contract = await getExchangeContract();

        contract.exchangeKHCToOtherChain(address, this.getDestContractAddress()).send({callValue:window.KHCExtension.toKoho(amount)}).then(res => {
            console.log('res', res);
            if (res) {
                this.checkHash(res);
            } else {
                Toast.fail(intl.get('CONTRACT_FAIL'), 2)
            }
        }).catch(
            res => {
                console.log('error = ', res);
                Toast.fail(intl.get('CONTRACT_FAIL'), 2)
            });
    }

    checkHash(hash) {
        window.KHCExtension.khc.getTransaction(hash).then(result => {
            if (!result.ret) {
                setTimeout(() => {
                    this.checkHash(hash)
                }, 2000);
                return;
            }

            console.log('result.ret ------->', result);

            if (result.ret && result.ret[0]['contractRet'] === 'SUCCESS') {
                Toast.hide();
                this.setState({successVisible:true});
            } else {
                Toast.fail(intl.get('CONTRACT_FAIL'), 2)
            }
        }).catch(()=>{
            this.checkHash(hash);
        });
    }

    getM20ContractAddress(){
        return this.getChain('KHC');
    }

    getDestContractAddress(asset = this.state.rightAsset){
        return this.getChain(asset);
    }

    getChain(chain){

        const {original, selectAsset} = this.state;

        let index = -1;

        for(let i = 0; i < original.length; i++)
        {
            const item = original[i];
            if(item.block_chain === chain && item.asset === selectAsset)
            {
                index = i;
                break;
            }
        }

        return original[index].contract_address;
    }

    getCurrentAddress(){

        const {leftAsset, addressArray} = this.state;

        let address = '';

        addressArray.map((item) => {
            if(item.blockChain === leftAsset)
            {
                address = item.address;
            }
        });

        return address;
    }

    IsETHAddress(ss) {
        return WAValidator.validate(ss, 'ETH');
    }

    IsKHCAddress(ss) {
        return window.KHCExtension.isAddress(ss);
    }

    IsTrxAddress(ss) {
        if (!ss || ss.length !== 34) {
            return false;
        }
        ss = ss.toLowerCase();//转小写方便处理
        let flag = true;
        if (ss[0] === 't') {
            for (let i = 1; i < ss.length; i++) {
                if ((ss[i] >= '0' && ss[i] <= '9') || (ss[i] <= 'z' && ss[i] >= 'a')) {

                } else {
                    flag = false;
                }
            }
        } else {
            flag = false;
        }

        return flag;
    }

    IsVDSAddress(ss) {
        if (!ss) {
            return false;
        }
        ss = ss.toLowerCase();//转小写方便处理
        let flag = true;
        if (ss[0] === 'v') {
            for (let i = 1; i < ss.length; i++) {
                if ((ss[i] >= '0' && ss[i] <= '9') || (ss[i] <= 'z' && ss[i] >= 'a')) {

                } else {
                    flag = false;
                }
            }
        } else {
            flag = false;
        }

        return flag;
    }

    checkAddress(val){

        const {rightAsset} = this.state;
        const type = this.getSelectChainName(rightAsset);
        this.setState({address:val});

        if(type === 'ETH'  || type === 'BSC' || type === 'RC20' || type === 'ERC20' || type === 'Ether'){
            let flag = this.IsETHAddress(val);
            if(flag){
                this.setState({addressErr:''})
            }
            else {
                this.setState({addressErr:intl.get('TEXT_8', {asset:(type === 'RC20' || type === 'BSC') ? 'BSC':'ETH'})})
            }
        } else if(type === 'TRON' || type === 'TRX' || type === 'TRC20'){
            let flag = this.IsTrxAddress(val);
            if(flag){
                this.setState({addressErr:''})
            }
            else {
                this.setState({addressErr:intl.get('TEXT_8', {asset:'TRON'})})
            }
        } else if(type === 'VDS' || type === 'Vollar'){
            let flag = this.IsVDSAddress(val);
            if(flag){
                this.setState({addressErr:''})
            }
            else {
                this.setState({addressErr:intl.get('TEXT_8', {asset:'VDS'})})
            }
        } else if(type === 'KHC' || type === 'KH20'){
            let flag = this.IsKHCAddress(val);
            if(flag){
                this.setState({addressErr:''})
            }
            else {
                this.setState({addressErr:intl.get('TEXT_8', {asset:'KHC'})})
            }
        }
    }

    checkMyAddress(){
        const {rightAsset, ethAddress, khcAddress, bscAddress, trxAddress} = this.state;
        let address = '';
        switch (rightAsset)
        {
            case 'ETH':
                address = ethAddress || '';
                break;
            case 'BSC':
                address = bscAddress || '';
                break;
            case 'TRON':
                address = trxAddress || '';
                break;
            case 'KHC':
                address = khcAddress || '';
                break;
        }

        this.setState({address:address});
    }

    async updateBalance(){
        const {leftAsset, selectAsset, ethAddress, khcAddress, bscAddress, trxAddress} = this.state;

        switch (leftAsset) {
            case 'ETH':
                if(ethAddress)
                {
                    if(selectAsset === 'ETH')
                    {
                        const web3 = await initWeb3();
                        const balance = await web3.eth.getBalance(ethAddress);
                        this.setState({currentBalance:fromDecimals(balance, this.getDecimals())});
                    }
                    else {
                        const balance20 = await getERC20Balance(ethAddress, this.getDestContractAddress(leftAsset));
                        this.setState({currentBalance:fromDecimals(balance20, this.getDecimals())});
                    }
                }
                else {
                    this.setState({currentBalance:null});
                }
                break;
            case 'BSC':
                if(bscAddress)
                {
                    const balance20 = await getRC20Balance(bscAddress, this.getDestContractAddress(leftAsset));
                    this.setState({currentBalance:fromDecimals(balance20, this.getDecimals())});
                }
                else {
                    this.setState({currentBalance:null});
                }
                break;
            case 'TRON':
                if(trxAddress)
                {
                    const balance20 = await getTRC20Balance(trxAddress,this.getDestContractAddress(leftAsset));
                    this.setState({currentBalance:fromDecimals(balance20, this.getDecimals())});
                }
                else {
                    this.setState({currentBalance:null});
                }
                break;
            case 'KHC':
                if(khcAddress)
                {
                    if(selectAsset === 'KHC')
                    {
                        const {kht} = this.props.redux.balance;
                        this.setState({currentBalance:kht});
                    }
                    else {
                        const balance20 = await getM20BalanceResult(this.getDestContractAddress(leftAsset));
                        this.setState({currentBalance:balance20});
                    }
                }
                else {
                    this.setState({currentBalance:null});
                }
                break;
        }
    }

    checkErr(){

        const {address, amount, env} = this.state;

        this.updateBalance();

        if(env > 1)
        {
            this.checkMyAddress();
        }
        else {
            if(address !== '')
            {
                this.checkAddress(address.toString());
            } else {
                this.setState({addressErr:''})
            }
        }

        if(amount !== '') {
            this.checkInput(amount.toString());
        } else {
            this.setState({amountErr:''})
        }
    }

    changeLanguage(lang) {
        setLanguage(lang).then(() => {
            this.setState({ lang })
            localStorage.setItem('lang', lang);
        })
    }

    getInputFlag(){

        const {env, leftAsset} = this.state;
        const isDeposit = this.isDeposit();
        const ethereum = window.ethereum;
        const tronWeb = window.tronWeb;
        const BinanceChain = window.BinanceChain;

        let networkVersion = 0;
        if(ethereum)
        {
            networkVersion = window.ethereum.networkVersion;
        }

        switch (env){
            case 1:
                return isDeposit;
            case 2:
                return leftAsset === 'VDS';
            case 3:
            {
                if(leftAsset === 'ETH')
                {
                    return !ethereum && isDeposit;
                }
                else if(leftAsset === 'BSC')
                {
                    if(BinanceChain)
                    {
                        return false;
                    }
                    else if(ethereum && Number(networkVersion) === 56)
                    {
                        return false;
                    }

                    return isDeposit;
                }
                else if(leftAsset === 'TRON')
                {
                    return !tronWeb && isDeposit;
                }

                return isDeposit;
            }
            default:
                return false;
        }
    }

    renderCard(){

        const {leftAsset, rightAsset} = this.state;

        const prefix = 'bridge-card';


        return (<div className={`${prefix}`}>
            <div className={'flex-between'} style={{padding:'5.33vw'}}>
                <div className={'flex-display-col'}>
                    <div className={`${prefix}-border flex-center`}>
                        <img alt='' src={imgs[leftAsset]} className={`${prefix}-border-icon`}/>
                    </div>
                    <div id="bridge-select" className={`${prefix}-bottom`}>
                        <div onClick={()=>{
                            this.setState({selectVisibleLeft:true});
                            const height = document.getElementById("bridge-select");
                            this.setState({selectTop:height.offsetTop - window.pageYOffset + height.offsetHeight})
                        }} style={{padding:'0 2.67vw', height:'100%'}} className={'flex-between'}>
                            <div className={`${prefix}-bottom-p`}>{leftAsset} Network</div>
                            <img alt='' src={imgs['arrow-bottom']} className={`${prefix}-bottom-arrow`} />
                        </div>
                    </div>
                </div>
                <img alt='' src={imgs['exchange']} onClick={()=>{this.reverse()}} className={`${prefix}-exchange`} />
                <div className={'flex-display-col'}>
                    <div className={`${prefix}-border flex-center`}>
                        <img alt='' src={imgs[rightAsset]} className={`${prefix}-border-icon`}/>
                    </div>
                    <div className={`${prefix}-bottom`}>
                        <div onClick={()=>{
                            this.setState({selectVisibleRight:true});
                            const height = document.getElementById("bridge-select");
                            this.setState({selectTop:height.offsetTop - window.pageYOffset + height.offsetHeight})
                        }} style={{padding:'0 2.67vw', height:'100%'}} className={'flex-between'}>
                            <div className={`${prefix}-bottom-p`}>{rightAsset} Network</div>
                            <img alt='' src={imgs['arrow-bottom']} className={`${prefix}-bottom-arrow`} />
                        </div>
                    </div>
                </div>
            </div>
        </div>)
    }

    renderTop(){
        const {selectAsset} = this.state;

        return (<div style={{width:'100vw'}}>
            <div style={{padding:'5.33vw'}}>
                <div className={'bridge-p1'} style={{textAlign:'left', marginBottom:'2.67vw'}}>
                    {intl.get('TEXT_7')}
                </div>
                <div id="bridge-search" onClick={()=>{
                    this.setState({searchVisible:true});
                    const height = document.getElementById("bridge-search");
                    this.setState({searchTop:height.offsetTop - window.pageYOffset + height.offsetHeight})
                }} className={'bridge-select'}>
                    <div style={{padding:'0 2.67vw', height:'100%'}} className={'flex-between'}>
                        <div className={'flex-display'}>
                            <div className={'bridge-select-border flex-center'}>
                                <img alt='' src={imgs[selectAsset]} className={'bridge-select-border-icon'} />
                            </div>
                            <div className={'bridge-p1'}>{selectAsset}</div>
                        </div>
                        <img alt='' src={imgs['arrow-bottom']} className={`bridge-card-bottom-arrow`} />
                    </div>
                </div>
            </div>
        </div>)
    }

    renderInput(){

        const {selectAsset, amount, amountErr, rightAsset, address, addressErr, currentBalance} = this.state;
        const fee = this.getFee();
        const getValue = amount === '' ? 0:new BigNumber(amount).minus(fee).toFixed(4);
        const value = fee === '-' ? '-':(getValue > 0 ? getValue:0);
        const isDeposit = this.getInputFlag();

        return (<div style={{width:'100vw'}}>
            <div style={{padding:'5.33vw'}}>
                <div className={'flex-between-end'} style={{marginBottom:'-1vw'}}>
                    <div className={'bridge-p1'}>{intl.get('TEXT_6')}</div>
                    <div style={{color:'#525066', fontSize:"3.2vw"}}>
                        {intl.get('TEXT_5')}{fee} {selectAsset}
                    </div>
                </div>
                <Input
                    width={'81.33vw'}
                    // title={'跨链数量' /*交易金额*/}
                    value={amount}
                    error={amountErr}
                    balance={'可用余额:' + getRound(currentBalance)}
                    onChange={(val) => {
                        this.checkInput(val)
                    }}
                />
                {!isDeposit ? <div>
                    <div className={'bridge-p1'} style={{textAlign:'left', marginBottom:'2.67vw', marginTop:'2.67vw'}}>
                        {rightAsset}{intl.get('TEXT_4')}
                    </div>
                    <Input
                        width={'81.33vw'}
                        value={address}
                        error={addressErr}
                        onChange={(val) => {
                            this.checkAddress(val)
                        }}
                    />
                </div> : null}
                <div className={'bridge-p1'} style={{textAlign:'left', marginBottom:'2.67vw', marginTop:'2.67vw'}}>
                    {intl.get('TEXT_3')}
                </div>
                <div className={'bridge-output'}>
                    <div style={{padding:'0 2.67vw', height:'100%'}} className={'flex-between'}>
                        <div className={'bridge-output-p'}>
                            {value}
                        </div>
                        <div className={'flex-display'}>
                            <div className={'bridge-select-border flex-center'}>
                                <img alt='' src={imgs[selectAsset]} className={'bridge-select-border-icon'} />
                            </div>
                            <div className={'bridge-p1'}>{selectAsset}{`(${this.getSelectChainName(rightAsset)})`}</div>
                        </div>
                    </div>
                </div>
            </div>
            <div style={{padding:'0 5.33vw'}}>
                <div className={`bridge-toast-get flex-display`} style={{marginTop:'2.67vw'}}>
                    <div className={`bridge-toast-get-p`}>
                        接下来，您将要进行两次授权签名，请确保您的余额足够
                        跨链、且足以支付区块链交易手续费。
                    </div>
                </div>
            </div>
        </div>)
    }

    renderBtn(){

        const {amount, amountErr, address, addressErr, env} = this.state;
        const isDeposit = this.getInputFlag();

        const disabled = isDeposit ? false :
            (address === '' || addressErr !== '' || !amount || amount === '' || amountErr !== '');

        return (<div onClick={disabled ? ()=>{}:()=>{this.btnClick()}} className={disabled ? 'bridge-btn bridge-disable':'bridge-btn'}>
            {isDeposit ? intl.get('TEXT_1'):intl.get('TEXT_2')}
        </div>)
    }

     renderAddress(){

        const {address} = this.props.redux;
        const {env, ethAddress, bscAddress} = this.state;

        const render0 =  <div className={'bridge-p1'} style={{marginLeft:'8vw'}} />;
        const render1 =  <div className={'bridge-p1'} style={{marginLeft:'8vw'}}>{address ? kidHidden(address):'-'}</div>;
        const render2 = (
            <div className={'flex-display'} style={{marginLeft:'8vw'}}>
                <div className={'relative bridge-addresses'}>
                    <img className={'bridge-addresses-icon'} alt='' src={imgs["khc-address"]} />
                    <img className={'bridge-addresses-ready'} alt='' src={imgs['ready']} />
                </div>
                <div className={'relative bridge-addresses'}>
                    <img className={'bridge-addresses-icon'} alt='' src={imgs["eth-address"]} />
                    <img className={'bridge-addresses-ready'} alt='' src={imgs['ready']} />
                </div>
                <div className={'relative bridge-addresses'}>
                    <img className={'bridge-addresses-icon'} alt='' src={imgs["bsc-address"]} />
                    <img className={'bridge-addresses-ready'} alt='' src={imgs['ready']} />
                </div>
                <div className={'relative bridge-addresses'}>
                    <img className={'bridge-addresses-icon'} alt='' src={imgs["trx-address"]} />
                    <img className={'bridge-addresses-ready'} alt='' src={imgs['ready']} />
                </div>
                <div className={'relative bridge-addresses'}>
                    <img className={'bridge-addresses-icon'} alt='' src={imgs["vds-address"]} />
                    {/*<img className={'bridge-addresses-ready'} alt='' src={imgs['ready']} />*/}
                </div>
            </div>
        )

        const render3 = (
            <div className={'flex-display'} style={{marginLeft:'8vw'}}>
                <div className={'relative bridge-addresses'}>
                    <img className={'bridge-addresses-icon'} alt='' src={imgs["khc-address"]} />
                    {getKHCAddress() ? <img className={'bridge-addresses-ready'} alt='' src={imgs['ready']} /> : null}
                </div>
                <div className={'relative bridge-addresses'}>
                    <img className={'bridge-addresses-icon'} alt='' src={imgs["eth-address"]} />
                    {ethAddress ? <img className={'bridge-addresses-ready'} alt='' src={imgs['ready']} /> : null}
                </div>
                <div className={'relative bridge-addresses'}>
                    <img className={'bridge-addresses-icon'} alt='' src={imgs["bsc-address"]} />
                    {bscAddress ? <img className={'bridge-addresses-ready'} alt='' src={imgs['ready']} /> : null}
                </div>
                <div className={'relative bridge-addresses'}>
                    <img className={'bridge-addresses-icon'} alt='' src={imgs["trx-address"]} />
                    {getTRXAddress() ? <img className={'bridge-addresses-ready'} alt='' src={imgs['ready']} /> : null}
                </div>
                <div className={'relative bridge-addresses'}>
                    <img className={'bridge-addresses-icon'} alt='' src={imgs["vds-address"]} />
                    {/*<img className={'bridge-addresses-ready'} alt='' src={imgs['ready']} />*/}
                </div>
            </div>
        )

        switch (env){
            case 0:
                return render0;
            case 1:
                return render1;
            case 2:
                return render2;
            case 3:
                return render3;
            default:
                return render0;
        }
    }

    renderCenter() {

        const {original, selectVisibleLeft, searchVisible, checkVisible, leftAsset, rightAsset,
            selectVisibleRight, qrcodeVisible, selectAsset, successVisible, failVisible, message, lang, env, selectTop, searchTop} = this.state;

        const searchAsset =  this.getSearchAssets();
        const fee = this.getFee();
        const isDeposit = this.isDeposit();

        const {address} = this.props.redux;
        const languages = {'en':'English', 'zh':'简体中文', 'jp':'日本語', 'ko':'한국어'};
        // const lang = localStorage.getItem('lang');

        const inputFlag = this.getInputFlag();

        return (
            <div className={'bridge'}>
                <ModalSearch isDeposit={isDeposit}
                             searchTop={searchTop}
                             assets={searchAsset} visible={searchVisible}
                             onSelect={(val)=>{
                                 this.onSelect(val)}}
                             onClose={()=>{this.setState({searchVisible:false})}}/>
                <ModalSelect chains={this.getMainChains()}
                             selectTop={selectTop}
                             visible={selectVisibleLeft} left={true}
                             onSelect={(val)=>{
                                 this.SelectAsset(val, 0);
                                 this.setState({selectVisibleLeft:false});
                             }}
                             onClose={()=>{this.setState({selectVisibleLeft:false})}}/>
                <ModalSelect chains={this.getMainChains()}
                             selectTop={selectTop}
                             visible={selectVisibleRight} left={false}
                             onSelect={(val)=>{
                                 this.SelectAsset(val, 1);
                                 this.setState({selectVisibleRight:false});
                             }}
                             onClose={()=>{this.setState({selectVisibleRight:false})}}/>
                 <ModalQRcode visible={qrcodeVisible}
                              asset={selectAsset}
                              fee={fee}
                              address={this.getCurrentAddress()}
                              myAddress={address}
                              onClose={()=>{this.setState({qrcodeVisible:false})}}
                 />
                 <ModalSuccess visible={successVisible} onClose={()=>{this.setState({successVisible:false})}}/>
                 <ModalFail visible={failVisible} message={message} onClose={()=>{this.setState({failVisible:false})}}/>
                 <ModalWalletChoose visible={checkVisible} onClose={(env, obj)=>{
                     this.setState({checkVisible:false});
                     this.checkEnv(env, obj);
                 }}/>
                <div className={'flex-display-col'}>
                    <div className={'flex-between'} style={{width:'100vw', marginTop:'5.33vw'}}>
                        {this.renderAddress()}
                        <div style={{marginRight:'4.53vw'}}>
                            <Popover mask
                                     overlayClassName="fortest"
                                     overlayStyle={{ color: 'currentColor' }}
                                     visible={this.state.visible}
                                     overlay={[
                                         (<Item key="4" value={'zh'}>
                                             <div className={'btn-sub flex-center'}>
                                                 <p className={'btn-text2'}>简体中文</p>
                                             </div>
                                         </Item>),
                                         (<Item key="5" value={'en'}>
                                             <div className={'btn-sub flex-center'}>
                                                 <p className={'btn-text2'}>English</p>
                                             </div>
                                         </Item>),
                                         (<Item key="6" value={'jp'}>
                                             <div className={'btn-sub flex-center'}>
                                                 <p className={'btn-text2'}>日本語</p>
                                             </div>
                                         </Item>),
                                         (<Item key="7" value={'ko'}>
                                             <div className={'btn-sub flex-center'}>
                                                 <p className={'btn-text2'}>한국어</p>
                                             </div>
                                         </Item>),
                                     ]}
                                     align={{
                                         overflow: { adjustY: 0, adjustX: 0 },
                                         offset: [-10, 0],
                                     }}
                                     onSelect={(opt)=>{
                                         this.setState({
                                             visible: false,
                                         }, ()=>{
                                             this.changeLanguage(opt.props.value);
                                         });
                                     }}
                            >
                                <div className={'btn-sub flex-center'} style={{marginRight:"4vw"}}>
                                    <p className={'bridge-p1'}>{languages[lang]}</p>
                                    <img style={{width:'3.2vw', height:'3.2vw', marginLeft:'1vw'}} alt="" src={imgs['arrow-bottom']}/>
                                </div>
                            </Popover>
                        </div>
                    </div>
                    {this.renderTop()}
                    {this.renderCard()}
                    {inputFlag ? null : this.renderInput()}
                    {this.renderBtn()}
                    <div onClick={()=>{window.location = "https://gas.khchain.io/#/reward"}} style={{color:'#4B3DB7', fontSize:'3.47vw', marginTop:'4vw', marginBottom:'4vw'}}>
                        {intl.get('TEXT_19')}
                    </div>
                </div>
            </div>
        );
    }

    renderLeft(){
        return (
            <div className={'bridge-left flex-between-col'}>
                <img alt='' src={imgs['logo']} style={{width:'165px', height:'100px', marginTop:'86px'}}/>
                <img alt='' src={imgs['left-bg']} style={{width:'368px', height:'368px'}}/>
            </div>
        )
    }

    render() {

        if(Storage.mobile)
        {
            return (
                <div>
                    {this.renderCenter()}
                </div>
            )
        }

        return <Web />
    }
}

export default connect(Index);
