import React, { Component } from "react";
import { Modal, Toast} from 'antd-mobile';
import intl from "react-intl-universal";
import {
    getETHAddress,
    getKHCAddress,
    getTRXAddress,
    getBSCAddress,
    getBitKeepKHC,
    getBitKeepETH, getBitKeepTRX, getBitKeepBSC
} from "../../../utils/getAddress";
import {addressHidden} from "../../../utils/kidHidden";

const imgs = {
    'hd':require('../../../images/bridge/hd.png'),
    'chrome':require('../../../images/bridge/chrome.png'),
    'khc':require('../../../images/bridge/k-wallet.png'),
    'back':require('../../../images/bridge/back.png'),
    'khc-address':require('../../../images/bridge/khc-address.png'),
    'eth-address':require('../../../images/bridge/eth-address.png'),
    'bsc-address':require('../../../images/bridge/bsc-address.png'),
    'trx-address':require('../../../images/bridge/trx-address.png'),
    'refresh':require('../../../images/bridge/refresh.png'),
}

const prefix = 'bridge-web-toast';

class ModalWalletChoose extends Component {

    constructor(props){
        super(props);
        this.state = {
            tab:3, //0初始，1 Khc钱包， 2 BitKeep钱包， 3 Chrome插件
        }
    }

    componentDidMount() {
        this.check();
    }

    async check() //2 Bitkeep钱包， 3 Chrome插件
    {
        const khc = getKHCAddress();
        this.setState({khc:khc});

        if(window.ethereum)
        {
            window.ethereum.request({method:'eth_requestAccounts'}).then((res)=>{
                getETHAddress().then((eth)=>{
                    if(eth){
                        this.setState({eth:eth});
                    }
                    else {
                        this.setState({eth:null});
                    }
                });
            });
        }

        const trx = getTRXAddress();
        this.setState({trx:trx});

        const bsc = await getBSCAddress();
        if(bsc){
            this.setState({bsc:bsc});
        }
        else {
            this.setState({bsc:null});
        }

        if(khc === null)
        {
            setTimeout(()=>{
                this.check();
            }, 2000)
        }
    }

    renderExtensionCell(url, address, flag){
        return (
            <div className={'flex-between'} style={{marginBottom:'20px', width:'100%'}}>
                <div className={'flex-display'}>
                    <img className={`${prefix}-icon-address`} src={url} alt='' />
                    {flag ? <div>
                        <div className={`${prefix}-p4`} style={{fontWeight:'normal', textAlign:'left'}}>
                            插件环境正常
                        </div>
                        <div className={`${prefix}-p1`} style={{fontWeight:'normal', textAlign:'left'}}>
                            {addressHidden(address)}
                        </div>
                    </div> : <div>
                        <div className={`${prefix}-p3`} style={{fontWeight:'normal', textAlign:'left'}}>
                            未检测到插件
                        </div>
                        <div className={`${prefix}-p1`} style={{fontWeight:'normal'}}>
                            请检查是否已安装或已解锁
                        </div>
                    </div>}
                </div>
                <div onClick={()=>{this.check()}} className={`${prefix}-refresh flex-center`}>
                    <img className={`${prefix}-refresh-icon`} src={imgs['refresh']}/>
                </div>
            </div>
        )
    }

    renderChrome(){

        const {onClose} = this.props;
        const {khc, trx, eth, bsc, tab} = this.state;
        const disable = !khc;

        return (
            <div className={'relative'} style={{padding:'39px 60px'}}>
                <div className={`${prefix}-title`} style={{fontWeight:'bold', marginBottom:'30px'}}>正在检测您的登录环境</div>
                <div className={'flex-display-col'} style={{alignItems: 'flex-start'}}>
                    {this.renderExtensionCell(imgs['khc-address'], khc, !!khc)}
                    {this.renderExtensionCell(imgs['eth-address'], eth, !!eth)}
                    {this.renderExtensionCell(imgs['bsc-address'], bsc, !!bsc)}
                    {this.renderExtensionCell(imgs['trx-address'], trx, !!trx)}
                    <div className={`${prefix}-get flex-display`} style={{marginTop:'24px'}}>
                        <div className={`${prefix}-get-p`} style={{textAlign:'left'}}>
                            未连接钱包插件的网络在进行跨链转出时，需要手动转账以完成跨链服务
                        </div>
                    </div>
                    <div className={`${prefix}-get flex-display`} style={{marginTop:'12px', width:'auto'}}>
                        <div className={`${prefix}-get-p`}>
                            请确认地址无误后再点击“GO！”
                        </div>
                    </div>
                </div>
                <div onClick={disable ? ()=>{}:()=>{onClose(tab, {khcAddress:khc, ethAddress:eth, bscAddress:bsc, trxAddress:trx})}} className={disable ? 'bridge-web-btn bridge-disable flex-center' : 'bridge-web-btn flex-center'} style={{width:'460px', marginTop:'44px'}}>
                    <div className={'bridge-web-btn-p'}>
                        GO
                    </div>
                </div>
            </div>
        )
    }

    render() {
        const { visible, onClose} = this.props;

        return (
            <Modal
                popup
                visible={visible}
                // onClose={()=>{onClose()}}
                // animationType="slide-up"
                // afterClose={() => { onClose() }}
            >
                <div className={'flex-center-col'} style={{width:'100vw', height:'100vh', backgroundColor:'rgba(60, 68, 76, 0.3)'}}>
                    <div className={`${prefix}`} style={{width:'auto'}}>
                        <div className={`${prefix}-bg`}>
                            {this.renderChrome()}
                        </div>
                    </div>
                </div>

            </Modal>
        );
    }
}

export default ModalWalletChoose;
