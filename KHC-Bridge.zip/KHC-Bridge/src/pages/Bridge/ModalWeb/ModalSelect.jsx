import React, { Component } from "react";
import { Modal} from 'antd-mobile';
import intl from "react-intl-universal";

const imgs = {
    'search':require('../../../images/bridge/search.png'),
    'ETH':require('../../../images/bridge/chain-ETH.png'),
    'VDS':require('../../../images/bridge/chain-VDS.png'),
    'TRON':require('../../../images/bridge/chain-TRX.png'),
    'USDT':require('../../../images/bridge/USDT.png'),
    'UNI':require('../../../images/bridge/UNI.png'),
    'KHC':require('../../../images/bridge/chain-KHC.png'),
    'BSC':require('../../../images/bridge/chain-BSC.png'),
}

class ModalSelect extends Component {

    constructor(props){
        super(props);
        this.state = {

        }
    }

    render() {
        const { visible, onClose, left, chains, onSelect, selectLeft} = this.props;

        const prefix = 'bridge-web-select-toast';

        // let marginLeft = '670px';
        //
        // if(!left) {
        //     marginLeft = '880px';
        // }

        return (
            <Modal
                popup
                visible={visible}
                maskClosable={true}
                onClose={()=>{onClose()}}
                transitionName={'1'}
                // animationType="slide-up"
                // afterClose={() => { onClose() }}
            >
                <div className={prefix} style={{marginLeft:selectLeft}}>
                    {chains.map((item, index)=> {
                       return <div onClick={()=>{onSelect(item)}} key={index} className={`${prefix}-row`}>
                           <div className={'flex-display'} style={{padding:'0 10px', height:'100%', backgroundColor:'white'}}>
                               <div className={`${prefix}-border flex-center`}>
                                   <img src={imgs[item]} alt='' className={`${prefix}-border-icon`} />
                               </div>
                               <div className={'bridge-web-p1'}>{item}</div>
                           </div>
                       </div>
                    })}
                </div>
            </Modal>
        );
    }
}

export default ModalSelect;
