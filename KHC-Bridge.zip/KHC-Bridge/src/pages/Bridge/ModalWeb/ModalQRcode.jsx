import React, { Component } from "react";
import { Modal, Toast} from 'antd-mobile';
import intl from "react-intl-universal";
import QRCode from 'qrcode.react';
import copy from "copy-to-clipboard";

const imgs = {
    'copy':require('../../../images/bridge/copy.png'),
    'close':require('../../../images/bridge/close.png'),
}

class ModalQRcode extends Component {

    constructor(props){
        super(props);
        this.state = {

        }
    }

    render() {
        const { visible, onClose, address, fee, asset, myAddress} = this.props;

        const prefix = 'bridge-web-toast';

        return (
            <Modal
                popup
                visible={visible}
                onClose={()=>{onClose()}}
                // animationType="slide-up"
                // afterClose={() => { onClose() }}
            >
                <div className={'flex-center-col'} style={{width:'100vw', height:'100vh', backgroundColor:'rgba(60, 68, 76, 0.3)'}}>
                    <div className={`${prefix}`}>
                        <img onClick={()=>{onClose()}} className={`${prefix}-close`} alt='' src={imgs['close']} />
                        <div className={'flex-display-col'} style={{padding:'30px 20px'}}>
                            <div className={`${prefix}-title`}>{intl.get('TEXT_12')}</div>
                            <QRCode
                                size={180}
                                value={address} />
                            <div className={'flex-display'} style={{marginTop:'30px'}}>
                                <div className={`${prefix}-address`}>{address}</div>
                                <img onClick={()=>{
                                    copy(address || '-');
                                    Toast.success(intl.get('COPY_SUCCESS'), 2, () => {}, false)
                                }} style={{width:'15px', height:'15px', marginLeft:'15px'}} alt='' src={imgs['copy']} />
                            </div>
                            <div style={{marginTop:'30px'}} className={`${prefix}-text`}>{intl.get('TEXT_13', {fee:fee, asset:asset})}</div>
                            <div className={`${prefix}-text`}>{intl.get('TEXT_14', {address:myAddress})}</div>
                        </div>
                    </div>
                </div>

            </Modal>
        );
    }
}

export default ModalQRcode;
