import React, { Component } from "react";
import { Modal, Toast} from 'antd-mobile';
import intl from "react-intl-universal";
import QRCode from 'qrcode.react';
import copy from "copy-to-clipboard";

const imgs = {
    'fail':require('../../../images/bridge/fail.png'),
    'close':require('../../../images/bridge/close.png'),
}

class ModalFail extends Component {

    constructor(props){
        super(props);
        this.state = {

        }
    }

    render() {
        const { visible, onClose, message} = this.props;

        const prefix = 'bridge-web-toast';

        return (
            <Modal
                popup
                visible={visible}
                onClose={()=>{onClose()}}
                // animationType="slide-up"
                // afterClose={() => { onClose() }}
            >
                <div className={'flex-center-col'} style={{width:'100vw', height:'100vh', backgroundColor:'rgba(60, 68, 76, 0.3)'}}>
                    <div className={`${prefix}`}>
                        <img onClick={()=>{onClose()}} className={`${prefix}-close`} alt='' src={imgs['close']} />
                        <div className={'flex-display-col'} style={{padding:'30px 20px'}}>
                            <img src={imgs['fail']} alt='' className={`${prefix}-icon`}  />
                            <div className={`${prefix}-title`}>{intl.get('TEXT_11')}</div>
                            <div className={`${prefix}-text`}>{message}</div>
                        </div>
                    </div>
                </div>

            </Modal>
        );
    }
}

export default ModalFail;
