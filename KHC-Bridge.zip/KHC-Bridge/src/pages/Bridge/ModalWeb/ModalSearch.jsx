import React, { Component } from "react";
import { Modal} from 'antd-mobile';
import intl from "react-intl-universal";

const imgs = {
    'search':require('../../../images/bridge/search.png'),
    'ETH':require('../../../images/bridge/chain-ETH.png'),
    'VDS':require('../../../images/bridge/chain-VDS.png'),
    'TRON':require('../../../images/bridge/chain-TRX.png'),
    'USDT':require('../../../images/bridge/USDT.png'),
    'UNI':require('../../../images/bridge/UNI.png'),
    'KHC':require('../../../images/bridge/chain-KHC.png'),
}

class ModalSearch extends Component {

    constructor(props){
        super(props);
        this.state = {
            asset:''
        }
    }

    getAssetsBySearch(value){
        let array = [];

        const {assets} = this.props;

        assets.map((item, index) => {
            if(item.asset.indexOf(value) !== -1 || item.asset.toLowerCase().indexOf(value) !== -1)
            {
                array.push(item);
            }
        })

        return array;
    }

    getType(item, isDeposit){
        console.log('item', item);

        if(isDeposit)
        {
            if(item.type === 'BASE' || item.type === 'KH20')
            {
                return this.getChainName(item.asset);
            }
            else {
                return item.type;
            }
        }
        else {
            return 'KH20';
        }
    }

    getChainName(asset){
        switch (asset){
            case 'ETH':
                return 'Ether';
            case 'KHC':
                return 'Koho';
            case 'USDT':
                return 'TRC20';
            case 'VDS':
                return 'Vollar';
        }
    }

    render() {
        const { visible, onClose, assets, onSelect, searchLeft} = this.props;
        const {asset} = this.state;

        const prefix = 'bridge-web-search-toast';

        let array = [];

        if(asset === '')
        {
            array = assets;
        }
        else {
            array = this.getAssetsBySearch(asset);
        }

        return (
            <Modal
                popup
                visible={visible}
                maskClosable={true}
                onClose={()=>{onClose()}}
                // animationType={'fade'}
                transitionName={'1'}
                // transparent={true}
                // animationType="slide-up"
                // afterClose={() => { onClose() }}
            >
                <div className={prefix} style={{marginLeft:searchLeft}}>
                    <div style={{padding:'20px', paddingBottom:'0'}}>
                        <div className={`${prefix}-input`}>
                            <div style={{padding:'0 10px', height:'100%'}} className={'flex-display'}>
                                <img alt='' src={imgs['search']} className={`${prefix}-input-icon`} />
                                <input
                                    className={`${prefix}-input-input`}
                                    placeholder={intl.get('TEXT_15')}
                                    type="text"
                                    value={asset}
                                    onChange={(value) => {
                                        this.setState({asset:value.target.value})
                                    }}
                                />
                            </div>
                        </div>
                        {array.length ? <div style={{marginTop:'10px'}}>
                            {array.map((item, index)=>{
                                return <div key={index} onClick={()=>{onSelect(item.asset)}} className={'flex-display'} style={{height:'44px'}}>
                                    <div className={`${prefix}-input-border flex-center`}>
                                        <img src={imgs[item.asset]} alt='' className={`${prefix}-input-border-icon`} />
                                    </div>
                                    <div className={'bridge-web-p1'}>{item.asset}</div>
                                </div>
                            })}
                        </div> : <div className={'bridge-web-p1'} style={{marginTop:'30px', paddingBottom:'30px'}}>
                            {intl.get('TEXT_16')}
                        </div>}
                    </div>
                </div>
            </Modal>
        );
    }
}

export default ModalSearch;
