import React, { Component } from "react";
import { Modal, Toast} from 'antd-mobile';
import intl from "react-intl-universal";
import QRCode from 'qrcode.react';
import copy from "copy-to-clipboard";

const imgs = {
    'success':require('../../../images/bridge/success.png'),
    'close':require('../../../images/bridge/close.png'),
}

class ModalSuccess extends Component {

    constructor(props){
        super(props);
        this.state = {

        }
    }

    render() {
        const { visible, onClose} = this.props;

        const prefix = 'bridge-web-toast';

        return (
            <Modal
                popup
                visible={visible}
                onClose={()=>{onClose()}}
                // animationType="slide-up"
                // afterClose={() => { onClose() }}
            >
                <div className={'flex-center-col'} style={{width:'100%', height:'100vh', backgroundColor:'rgba(60, 68, 76, 0.3)'}}>
                    <div className={`${prefix}`}>
                        <img onClick={()=>{onClose()}} className={`${prefix}-close`} alt='' src={imgs['close']} />
                        <div className={'flex-display-col'} style={{padding:'30px 20px'}}>
                            <img src={imgs['success']} alt='' className={`${prefix}-icon`}  />
                            <div className={`${prefix}-title`}>{intl.get('TEXT_17')}</div>
                            <div className={`${prefix}-text`}>{intl.get('TEXT_18')}</div>
                        </div>
                    </div>
                </div>

            </Modal>
        );
    }
}

export default ModalSuccess;
