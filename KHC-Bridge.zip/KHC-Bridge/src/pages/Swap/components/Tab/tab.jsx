import React, {Component} from "react";
import {LanguageContext} from '../../../languageContext';

const images = {
	en: require('../../../../images/zh.png'),
	zh: require('../../../../images/en.png'),
}

class Tab extends Component {
	constructor(props) {
		super(props);

		this.state = {};

	}

	componentDidMount() {
	}

	render() {
		const {tab, onChange, tab0Title, tab1Title, clickSec} = this.props;
		return (
			<LanguageContext.Consumer>
				{({language, setLanguage}) => (
					<div className="select-tab flex-center">
						<div className={'select-tab-container flex-between'}>
							<div onClick={() => onChange(0)}>
								<div className={tab ? 'not-sec' : 'sec'}>{tab0Title}</div>
							</div>
							<div onClick={() => onChange(1)}>
								<div className={tab ? 'sec' : 'not-sec'}>{tab1Title}</div>
							</div>
						</div>
						{
							clickSec ?
								(
									<>
										<img className="language" src={images[language]} onClick={() => setLanguage(language === 'zh' ? 'en' : 'zh')}/>
										<img src={require('../../../../images/otc/more.png')} onClick={() => clickSec()}/>
									</>
								)
								:
								null
						}
					</div>
				)}
			</LanguageContext.Consumer>
		);
	}
}

export default Tab;
