import React, { Component } from "react";
import { Modal} from 'antd-mobile';
import {Input} from "../index";
import intl from "react-intl-universal";

class ModalPoolAdd extends Component {

    constructor(props){
        super(props);
        this.state = {
            tab:0,
        }
    }

    render() {
        const { visible, onClose} = this.props;
        return (
            <div>
                <Modal
                    popup
                    visible={visible}
                    onClose={()=>{onClose()}}
                    animationType="slide-up"
                    // afterClose={() => { onClose() }}
                >
                    <div className={'swap-modal-pool'}>
                        <div className={'swap-modal-pool-header flex-between'} style={{padding:"0 5.33vw"}}>
                            <img className={'btn-back'} alt="" src={require('../../../../images/swap/back.png')}/>
                            <p style={{color:"#221814", fontSize:"4.53vw"}}>添加流动性份额</p>
                            <img onClick={()=>{onClose()}} className={'btn-close'} alt="" src={require('../../../../images/swap/close.png')}/>
                        </div>
                        <div style={{height:"1px", width:"94.67vw", backgroundColor:"#F3F7F7", marginLeft:"2.67vw"}}/>
                        <p className={'swap-p4'} style={{color:"#E15502", lineHeight:"6.4vw", textAlign:"left", padding:"0 5.33vw"}}>
                            您将是第一位资金池流动性提供者，您提供给资金池的数量，将决定初始兑换价格。
                        </p>
                        <div>
                            <div className={'flex-between'} style={{width:'89.33vw', marginBottom:"-5vw"}}>
                                <div className={'common-input-label'}>XCN数量</div>
                                <div className={'common-input-subLabel'}>可用余额：XXX.XXXX XCN</div>
                            </div>
                            <div className={'flex-display'} style={{padding:"0 4vw", width:"81.33vw"}}>
                                <Input
                                    width={'58.67vw'}
                                    // title={'您需要支付的数量' /*交易金额*/}
                                    tag={''}
                                    value={this.state.noFeePrice}
                                    error={this.state.noFeePriceErr}
                                    onChange={(val) => {
                                        this.inputChange(val, 1)
                                    }}
                                />
                                <div className={'swap-content-asset-choose flex-display'} style={{marginTop:"-1vw"}}>
                                    <img className={'icon-xin'} alt="" src={require('../../../../images/swap/xin-logo.png')}/>
                                    <p className={'swap-p2'}>XCN</p>
                                    <img className={'icon-down-arrow'} alt="" src={require('../../../../images/swap/arrow-down.png')}/>
                                </div>
                            </div>
                        </div>
                        <div>
                            <div className={'flex-between'} style={{width:'89.33vw', marginBottom:"-5vw"}}>
                                <div className={'common-input-label'}>XCN数量</div>
                                <div className={'common-input-subLabel'}>可用余额：XXX.XXXX USDT</div>
                            </div>
                            <div className={'flex-display'} style={{padding:"0 4vw", width:"81.33vw"}}>
                                <Input
                                    width={'58.67vw'}
                                    // title={'您需要支付的数量' /*交易金额*/}
                                    tag={''}
                                    value={this.state.noFeePrice}
                                    error={this.state.noFeePriceErr}
                                    onChange={(val) => {
                                        this.inputChange(val, 1)
                                    }}
                                />
                                <div className={'swap-content-asset-choose flex-display'} style={{marginTop:"-1vw"}}>
                                    <img className={'icon-xin'} alt="" src={require('../../../../images/swap/xin-logo.png')}/>
                                    <p className={'swap-p2'}>XCN</p>
                                    <img className={'icon-down-arrow'} alt="" src={require('../../../../images/swap/arrow-down.png')}/>
                                </div>
                            </div>
                        </div>
                        <div style={{padding:"0 5.33vw"}}>
                            <p className={'swap-p4'} style={{textAlign:"left", lineHeight:"6.13vw", fontWeight:"bold"}}>
                                若链上兑换价格发生变化，您希望智能合约如何处理？
                            </p>
                            <div>
                                <div className={'flex-display'}>
                                    <div onClick={()=>{this.setState({tab:0})}} className={'swap-choose flex-center'}>
                                        {this.state.tab === 0 ? <div className={'swap-center'} /> : null}
                                    </div>
                                    <div className={'swap-choose-bg flex-display'}>
                                        <div className={'swap-p4'}>
                                            以支出数量的最大份额加入，剩余数量返还给我
                                        </div>
                                    </div>
                                </div>
                                <div className={'flex-display'} style={{marginTop:"4vw"}}>
                                    <div onClick={()=>{this.setState({tab:1})}} className={'swap-choose flex-center'}>
                                        {this.state.tab === 1 ? <div className={'swap-center'} /> : null}
                                    </div>
                                    <div className={'swap-choose-bg flex-display'}>
                                        <div className={'swap-p4'}>
                                            结束本次操作，将全部支出数量返还给我
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className={'flex-between'}>
                                <p className={'swap-p5'}>添加成功后您的份额</p>
                                <p className={'swap-p6'}>XXXX.XXXX</p>
                            </div>
                            <div className={'flex-between'}>
                                <p className={'swap-p5'}>添加成功后您的份额占比预估</p>
                                <p className={'swap-p6'}>XX.XX%</p>
                            </div>
                            <div className={'swap-btn flex-center'} style={{margin:"5.33vw 0", width:"89.33vw"}}>
                                <p className={'btn-text'}>加入资金池</p>
                            </div>
                        </div>
                    </div>
                </Modal>
            </div>
        );
    }
}

export default ModalPoolAdd;
