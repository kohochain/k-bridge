import React, { Component } from "react";
import connect from "../../../../store/connect";

class SystemMaintanance extends Component {

    constructor(props){
        super(props);
        this.state = {

        }
    }

    render() {
        return (
            <div style={{display:'flex', justifyContent:"center", alignItems:"center", flexDirection:"column",
                position:"absolute", zIndex:9999, backgroundColor:"rgba(125, 110, 103, 0.7)", left:0, top:0, width:"100%", height:"100%"}}>
                <img style={{width:"53.33vw", height:"38.13vw"}} alt="" src={require('../../../../images/swap/system-maintenance.png')}/>
                <div style={{fontSize:"3.73vw", marginTop:"6.67vw", color:"white"}}>系统升级中，请稍后访问</div>
            </div>
        );
    }
}

export default connect(SystemMaintanance);
