import React, { Component } from "react";
import { Modal} from 'antd-mobile';
import {Input} from "../index";
import intl from "react-intl-universal";
import connect from "../../../../store/connect";

class ModalTokenList extends Component {

    constructor(props){
        super(props);
        this.state = {

        }
    }

    getTokensById(id){

        let tokens = this.props.redux.tokenList;

        for(let i = 0;i < tokens.length; i++){
            if(tokens[i].id === id){
                return tokens[i];
            }
        }
        return {};
    };

    render() {
        const { visible, onClose, quoteToken, type, onSelect, baseToken} = this.props;


        // let token = this.getTokensById(baseToken);
        // let isUSDT = false;
        // if(token.name === 'USDT')
        // {
        //     isUSDT = true;
        // }

        return (
            <div>
                <Modal
                    popup
                    visible={visible}
                    onClose={()=>{onClose()}}
                    animationType="slide-up"
                    // afterClose={() => { onClose() }}
                >
                    <div className={'swap-modal-pool'} style={{maxHeight:"161vw"}}>
                        <div className={'swap-modal-pool-header flex-between'} style={{padding:"0 5.33vw"}}>
                            <div className={'btn-close'}/>
                            <p style={{color:"#221814", fontSize:"4.53vw"}}>请选择币种</p>
                            <img onClick={()=>{onClose()}} className={'btn-close'} alt="" src={require('../../../../images/swap/close.png')}/>
                        </div>
                        <div style={{height:"1px", width:"94.67vw", backgroundColor:"#F3F7F7", marginLeft:"2.67vw"}}/>
                        <div>
                            {this.props.redux.tokenList.map((item, index) => {
                                if(item.enableSwap)
                                {
                                    // if((isUSDT && (item.id === quoteToken || item.name === 'USDT')) || !isUSDT)
                                    // {
                                        return (
                                            <div
                                                onClick={quoteToken === item.id ? ()=>{}:()=>{onSelect(item.id)}}
                                                className={'flex-between'} style={{height:"16.8vw", padding:"0 5.33vw"}}>
                                                <div className={'flex-display'}>
                                                    <img style={{width:"8.8vw", height:"8.8vw", borderRadius:"50%", border: "#fff0e6 2px solid", marginRight:"2.67vw"}} alt="" src={item.logo}/>
                                                    <div style={{color:"#221814", fontSize:"4vw"}}>{item.name}</div>
                                                </div>
                                                {quoteToken === item.id ? <div style={{color:"#C1A59A", fontSize:"3.47vw"}}>
                                                    {!type ? "已选择为支付币种":"已选择为兑换币种"}
                                                </div> : null}
                                            </div>
                                        )
                                    // }
                                }
                            })}
                        </div>
                    </div>
                </Modal>
            </div>
        );
    }
}

export default connect(ModalTokenList);
