import React, {Component} from "react";
import net from '../../server';
import connect from '../../store/connect';
import {Input} from './components';
import {Popover, Toast, Modal} from 'antd-mobile';
import {extensionErr, inuputCheck} from '../../lib';
import ModalPool from "./components/Modal/ModalPool";
import ModalPoolExit from "./components/Modal/ModalPoolExit";
import ModalPoolAdd from "./components/Modal/ModalPoolAdd";
import ModalTokenList from "./components/Modal/ModalTokenList";
import ModalPoolList from "./components/Modal/ModalPoolList";
import {signTimestamp, get20Contract} from "../../utils/mdc";
import {BigNumber} from "bignumber.js";
import ReactEcharts from 'echarts-for-react';
import echarts from 'echarts'
import moment from 'moment';
import intl from "react-intl-universal";
import SystemMaintanance from "./components/Modal/SystemMaintanance";
// import mdc from '../../utils/mdc'

const Item = Popover.Item;

const contractAddress = process.env.REACT_APP_CONTRACT_ADDRESS;

class Swap extends Component {

    constructor(props){
        super(props);
        this.state = {
            tab: 0,
            poolVisible:false,
            poolExitVisible:false,
            poolAddVisible:false,
            tokenListVisible:false,
            poolList:[],
            data:{},
            down:[],
            baseToken:0,
            quoteToken:0,
            list:[],
            timeType:0,
            priceType:0,
            fees:[],
            exchangeAmount:0,
            payAmount:0,
            isClick:false,
            type:0,
            tokenPath:[],
        }
    }

    componentDidMount(){
        // this.getCoinList();
        // this.getAddressInfo();
        this.login();
        this.getRC20Balance();
    }

    getRC20Balance(){

        const {address} = this.props.redux;
        if (address) {
            net.getRC20Balance({address:address}).then(res => {
                if(res.response_code === '00')
                {
                    this.props.setBalance(res.content);
                }
            });
        }

        setTimeout(() => this.getRC20Balance(), 5000);
    }

    async login() {
        const {address} = this.props.redux;

        Toast.loading(intl.get('WAITING'), 0);

        if (address) {

            // let params = await signTimestamp();
            //
            // net.postAuthLogin(params).then(res => {
            //     if (res.code === '00') {
            //         // this.props.setActive(res.content.active)
            //         this.getData();
            //     }
            //     else {
            //         Toast.fail(res.msg);
            //     }
            // });

            this.getData();
        } else {
            setTimeout(() => this.login(), 3000)
        }
    }

    getData(){
        this.getPoolList(0);
        this.getTokenList();
        this.getAccountInfo();
    }

    getPoolInfo(flag = 1){

        let type = 'price';

        switch (this.state.priceType) {
            case 0:
                type = 'price';
                break;
            case 1:
                type = 'total';
                break;
            case 2:
                type = 'volume';
                break;
        }

        net.getApiStatistics({getToken:this.state.quoteToken, payToken:this.state.baseToken, interval:this.state.timeType + 1, type:type}).then(res => {
            if (res.code === '00') {
                this.setState(res.content);
                if(flag === 0)
                {
                    net.postApiSwapPre({type:0, payToken:this.state.quoteToken, getToken:this.state.baseToken}).then(res => {
                        if (res.code === '00') {
                            this.setState(res.content)

                        } else {
                            Toast.fail(res.msg);
                        }
                    });
                }
            }
            else {
                Toast.fail(res.msg);
            }
        });
    }

    getTokenList(){
        net.getApiTokenList().then(res => {
            Toast.hide();
            if (res.code === '00') {
                this.props.setTokenList(res.content);
            }
            else {
                Toast.fail(res.msg);
            }
        });
    }

    getPoolList(type){

        net.getApiPoolList().then(res => {
            if (res.code === '00') {
                this.setState({poolList:res.content});
                if(res.content.length)
                {
                    if(type === 0)
                    {
                        let flag = this.props.match.url.indexOf('ATA') !== -1;

                        this.setState({data:res.content[0], quoteToken:flag ? 2:res.content[0].quoteToken, baseToken:flag ? 4:res.content[0].baseToken}, ()=>{
                            this.getPoolInfo();
                            if(type === 0)
                            {
                                net.postApiSwapPre({type:0, payToken:this.state.quoteToken, getToken:this.state.baseToken}).then(res => {
                                    if (res.code === '00') {
                                        this.setState(res.content)

                                    } else {
                                        Toast.fail(res.msg);
                                    }
                                });
                            }
                        });
                    }
                    else {
                        this.setState({data:res.content[0]}, ()=>{
                            this.getPoolInfo();
                            if(type === 0)
                            {
                                net.postApiSwapPre({type:0, payToken:this.state.baseToken, getToken:this.state.quoteToken}).then(res => {
                                    if (res.code === '00') {
                                        this.setState(res.content)

                                    } else {
                                        Toast.fail(res.msg);
                                    }
                                });
                            }
                        });
                    }

                    let down = [];
                    for(let i = 0; i < res.content.length; i++)
                    {
                        down.push(true);
                    }
                    this.setState({down:down});
                }
            }
            else {
                Toast.fail(res.msg);
            }
        });

        setTimeout(() => this.getPoolList(1), 10000);
    }

    getAccountInfo(){
        const {address} = this.props.redux;
        if (address) {
            net.getApiAccount({address:address}).then(res => {
                if (res.code === '00') {
                    this.props.setAccount(res.content);
                }
                else {
                    Toast.fail(res.msg);
                }
            });
        }

        setTimeout(() => this.getAccountInfo(), 10000);
    }

    getAmount(type){
        net.postApiSwapPre({type:type, payToken:this.state.quoteToken, getToken:this.state.baseToken, payQuantity:this.state.payAmount, getQuantity:this.state.exchangeAmount}).then(res => {
            this.setState({isClick:false});
            if (res.code === '00') {
                this.setState(res.content);
                if(type === 1)
                {
                    this.setState({payAmount:res.content.payQuantity !== 'NaN' ? Math.ceil(new BigNumber(res.content.payQuantity).times(10000).toNumber())/10000:0});
                    if(Number(res.content.payQuantity) > Number(this.getBalanceByTokenID(this.state.quoteToken)))
                    {
                        this.setState({payAmountErr:intl.get('TEXT_92')});
                    }
                    else {
                        this.setState({payAmountErr:""});
                    }
                }
                else {
                    this.setState({exchangeAmount:res.content.getQuantity !== 'NaN' ? new BigNumber(res.content.getQuantity).toFixed(4, 1):0})
                }

            } else {
                Toast.fail(res.msg);
            }
        });
    }

    checkInput(val, index) {  // 0 数量 1 单价 2 最小交易数量 3 最大交易数量
        let value = inuputCheck(val,  4);
        if (value[value.length - 1] === '.' || value[value.length - 1] === '0') {
        } else {
            value = value ? Number(value) : '';
        }
        if(index === 0){
            this.setState({exchangeAmount:value});
            if(Number(this.state.getTokenPoolQuantity) < value)
            {
                this.setState({exchangeAmountErr:intl.get('TEXT_93')});
            }
            else {
                this.setState({exchangeAmountErr:""});
                this.setState({type:1}, ()=>{
                    this.getAmount(1);
                })
            }
        }
        else {
            this.setState({payAmount:value});

            if(value > Number(this.getBalanceByTokenID(this.state.quoteToken)))
            {
                this.setState({payAmountErr:"余额不足"});
            }
            else {
                this.setState({payAmountErr:""});
                this.setState({type:0}, ()=>{
                    this.getAmount(0);
                })
            }
        }
    }


    async swap() {

        if(this.props.redux.balance.mdc === 0)
        {
            this.setState({modal3:true});
            return ;
        }


        if(sessionStorage.getItem("exchange") !== 'true')
        {
            this.setState({modal1:true});
            sessionStorage.setItem("exchange", "true");
            return ;
        }

        Toast.loading(intl.get('WAITING'), 0);

        let contract = this.getTokensById(this.state.quoteToken).contractAddress;

        if (this.getTokensById(this.state.quoteToken).name === 'MDC') {
            window.MDCExtension.contract().at(contractAddress).then(functions => functions.swap(this.state.quoteToken, this.state.baseToken, this.toSun(this.state.quoteToken, this.state.payAmount)).send(
                {callValue: this.toSun(this.state.quoteToken, this.state.payAmount)}
            ))
                .then(res => {
                    if (res) {
                        this.checkHash(res);
                    } else {
                        Toast.fail('调用合约失败', 2)
                    }
                }).catch(
                res => {
                    console.log('error = ', res);
                    Toast.fail('调用合约失败', 2)
                }
            )
        } else {

            let functions = await get20Contract(contract);

            functions.approve(contractAddress, this.toSun(this.state.quoteToken, this.state.payAmount)).send().then(res => {
                this.getApproveResult(res);
            }).catch(
                res => {
                    let err = extensionErr(res);
                    Toast.fail(err, 2, () => {
                    }, false);
                });
        }
    }

    getApproveResult(res) {
        console.log('result.ret ------->', res);
        window.MDCExtension.trx.getTransaction(res).then(result => {
            if (!result.ret) {
                setTimeout(() => {
                    this.getApproveResult(res)
                }, 2000);
                return;
            }

            console.log('result.ret ------->', result);

            if (result.ret && result.ret[0]['contractRet'] === 'SUCCESS') {
                this.swap2();
            } else {
                Toast.fail(intl.get('APPROVE_FAIL'), 2)
            }
        }).catch(()=>{
            this.getApproveResult(res);
        })
    }

    swap2(){
        window.MDCExtension.contract().at(contractAddress).then(functions => functions.swap(this.state.quoteToken, this.state.baseToken, this.toSun(this.state.quoteToken, this.state.payAmount)).send())
            .then(res => {
                if (res) {
                    this.checkHash(res);
                    // Toast.success('兑换请求已提交，请等待区块链进行处理', 2);
                } else {
                    Toast.fail('调用合约失败', 2)
                }
            }).catch(
            res => {
                console.log('error = ', res);
                Toast.fail('调用合约失败', 2)
            }
        )
    }

    reverse(){

        if(this.state.isClick)
        {
            return;
        }

        this.setState({isClick:true});

        let baseToken = this.state.baseToken;
        let quoteToken = this.state.quoteToken;
        let exchangeAmount = 0;
        let payAmount = 0;

        this.setState({baseToken:quoteToken, quoteToken:baseToken, exchangeAmount:payAmount, payAmount:exchangeAmount, type: 1 - this.state.type}, ()=>{
            this.getPoolInfo();
            this.getAmount(this.state.type);
        })
    }

    toSun(id, amount){
        let token = this.getTokensById(id);

        return  new BigNumber(amount).times(10**token.decimal).toFixed(0);
    }

    renderExchange(){

        let token1 = this.getTokensById(this.state.baseToken);
        let token2 = this.getTokensById(this.state.quoteToken);

        if(!token1.name)
        {
            return (
                <div className={'flex-display'} style={{padding:"0 4vw", width:"81.33vw", height:"20vw"}}>

                </div>
            )
        }

        let baseQuantity = new BigNumber(this.state.exchangeAmount);
        let quoteQuantity = new BigNumber(this.state.payAmount);
        let ratio = quoteQuantity.div(baseQuantity);
        if(Number(baseQuantity) === 0 || Number(quoteQuantity) === 0)
        {
            ratio = 0;
        }

        let disable = !this.state.payAmount || Number(this.state.payAmount) === 0 || !this.state.exchangeAmount || Number(this.state.exchangeAmount) === 0 || this.state.payAmountErr || this.state.exchangeAmountErr;

        return (
            <div className={'flex-display-col'}>
                <div className={'flex-between'} style={{width:'81.33vw', marginTop:"2vw", marginBottom:"-1vw"}}>
                    <div className={'common-input-label'} style={{margin:"0"}}>目标兑换数量(请以实际到账为准)</div>
                    <img onClick={()=>{this.setState({modal1:true})}} style={{height:"5.07vw", width:"5.07vw"}} alt="" src={require('../../images/swap/info.png')} />
                </div>
                <div className={'flex-display'} style={{padding:"0 4vw", width:"81.33vw"}}>
                    <Input
                        width={'43.33vw'}
                        // title={'目标兑换数量(请以实际到账为准)' /*交易金额*/}
                        tag={''}
                        // onBlur={()=>{
                        //     this.setState({type:1}, ()=>{
                        //         this.getAmount(1);
                        //     })
                        // }}
                        value={this.state.exchangeAmount}
                        // error={this.state.exchangeAmountErr}
                        onChange={(val) => {
                            this.checkInput(val, 0)
                        }}
                    />
                    <div onClick={()=>{this.setState({tokenListVisible:true})}} className={'swap-content-asset-choose flex-display'} style={{marginTop:"-1vw"}}>
                        <img className={'icon-xin'} alt="" src={token1.logo}/>
                        <p className={'swap-p2'}>{token1 ? token1.name : '-'}</p>
                        <img className={'icon-down-arrow'} alt="" src={require('../../images/swap/arrow-down.png')}/>
                    </div>
                </div>
                {this.state.exchangeAmountErr !== "" ? <div className={'flex-end-col'} style={{width:"100%", marginTop:"-2.67vw", padding:"0 5.33vw 0 0"}}>
                    <div className={'swap-error'}>{this.state.exchangeAmountErr}</div>
                </div> : null}
                <img onClick={()=>{this.reverse()}} style={{width:"7.47vw", height:"7.47vw", transform:"rotate(180deg)"}} src={require('../../images/swap/exchange.png')} alt=""/>
                <div className={'flex-between'} style={{width:'81.33vw', marginTop:"2vw", marginBottom:"-1vw"}}>
                    <div className={'common-input-label'} style={{margin:"0"}}>您需要支付的数量</div>
                    <div className={'common-input-subLabel'}>可用余额：{this.getBalanceByTokenID(this.state.quoteToken)} {this.getTokensById(this.state.quoteToken).name}</div>
                </div>
                <div className={'flex-display'} style={{padding:"0 4vw", width:"81.33vw"}}>
                    <Input
                        width={'43.33vw'}
                        // title={'您需要支付的数量' /*交易金额*/}
                        subTitle={'可用余额：XXX.XXXX MDC'}
                        // onBlur={()=>{
                        //     this.setState({type:0}, ()=>{
                        //         this.getAmount(0);
                        //     })
                        // }}
                        tag={''}
                        value={this.state.payAmount}
                        // error={this.state.payAmountErr}
                        onChange={(val) => {
                            this.checkInput(val, 1)
                        }}
                    />
                    <div onClick={()=>{this.setState({tokenListVisible2:true})}} className={'swap-content-asset-choose flex-display'} style={{marginTop:"-1vw"}}>
                        <img className={'icon-xin'} alt="" src={token2.logo}/>
                        <p className={'swap-p2'}>{token2 ? token2.name : '-'}</p>
                        <img className={'icon-down-arrow'} alt="" src={require('../../images/swap/arrow-down.png')}/>
                    </div>
                </div>
                {this.state.payAmountErr !== "" ? <div className={'flex-end-col'} style={{width:"100%", marginTop:"-2.67vw", padding:"0 5.33vw 0 0"}}>
                    <div className={'swap-error'}>{this.state.payAmountErr}</div>
                </div> : null}
                <div className={'flex-between'} style={{width:'81.33vw'}}>
                    <div className={'swap-p3'}>价格</div>
                    <div className={'swap-p4'}>每兑换1个{token1.name}，需要{!isNaN(ratio) && Number(ratio) !== 0 ? ratio.toFixed(4) : "-"}个{token2.name}</div>
                </div>
                <div onClick={disable ? ()=>{}:()=>{this.swap()}} className={disable ? 'swap-btn-disable flex-center' : 'swap-btn flex-center'} style={{margin:"5.33vw 0"}}>
                    <p className={'btn-text'}>兑换</p>
                </div>
            </div>
        )
    }

    getTokensById(id){

        let tokens = this.props.redux.tokenList;

        for(let i = 0;i < tokens.length; i++){
            if(tokens[i].id === id){
                return tokens[i];
            }
        }
        return {};
    };

    getPoolById(id){
        let bonus = this.props.redux.account.bonus;

        for(let i = 0;i < bonus.length; i++){
            if(bonus[i].poolId === id){
                return bonus[i];
            }
        }
        return 0;
    }

    getPoolListById(id){
        let poolList = this.state.poolList;
        for(let i = 0;i < poolList.length; i++){
            if(poolList[i].id === id){
                return poolList[i];
            }
        }
        return 0;
    }

    getShareById(id){
        let share = this.props.redux.account.share;

        for(let i = 0;i < share.length; i++){
            if(share[i].poolId === id){
                return share[i];
            }
        }
        return 0;
    }

    getBalanceByTokenID(id){
        let token = this.getTokensById(id);

        let balances = this.props.redux.balances;

        if(token.name === 'MDC')
        {
            return  this.props.redux.balance.mdc;
        }

        for(let i = 0;i < balances.length; i++){
            if(balances[i].abbr === token.name){
                return new BigNumber(balances[i].balance).toFixed(4,1);
            }
        }
    }

    checkHash(hash) {
        window.MDCExtension.trx.getTransaction(hash).then(result => {
            if (!result.ret) {
                setTimeout(() => {
                    this.checkHash(hash)
                }, 2000);
                return;
            }

            console.log('result.ret ------->', result);

            if (result.ret && result.ret[0]['contractRet'] === 'SUCCESS') {
                Toast.success('请求已提交，请等待区块链进行处理');
            } else {
                Toast.fail('调用合约失败', 2)
            }
        }).catch(()=>{
            this.checkHash(hash);
        });
    }

    getReward(){

        if(this.props.redux.balance.mdc === 0)
        {
            this.setState({modal3:true});
            return ;
        }

        let {account} = this.props.redux;
        let quantity = 0;
        let xcnQuantity = 0;
        if(account.bonus.length)
        {
            quantity = account.bonus[0].quantity;
            xcnQuantity = account.bonus[0].xcnQuantity;
        }
        let fee = 0;
        if(account.contractFee.length > 1)
        {
            fee = account.contractFee[1].quantity;
        }

        if(Number(quantity) <= Number(fee)){
            this.setState({modal4:true});
            return ;
        }

        Toast.loading(intl.get('WAITING'), 0);

        window.MDCExtension.contract().at(contractAddress).then(functions => functions.getBonus().send())
            .then(res => {
                if (res) {
                    this.checkHash(res);
                } else {
                    Toast.fail('调用合约失败', 2)
                }
            }).catch(
            res => {
                console.log('error = ', res);
                Toast.fail('调用合约失败', 2)
            }
        )
    }

    getOption =()=> {

        let left = [];
        let right = [];
        for (let i = 0; i < this.state.list.length; i++)
        {
            let format = 'HH:mm';

            switch (this.state.timeType) {
                case 0:
                    format = 'HH:mm';
                    break;
                case 1:
                    format = 'HH';
                    break;
                case 2:
                    format = 'MM-DD ';
                    break;
            }

            left.push(moment(this.state.list[i].time).format(format));
            right.push(this.state.list[i].value);
        }

        return {
            grid: {
                left: '1%',
                right: '1%',
                bottom: '10%',
                containLabel: true,
            },
            xAxis: {
                type: 'category',
                boundaryGap: false,
                // show:false,
                data: left
            },
            yAxis: {
                type: 'value',
                // show:false,
                splitLine: { //网格线
                    show: false
                },
                scale:true
            },
            dataZoom: [
                {
                    type: 'inside',
                    show: true,
                    start: 80,
                    end: 100
                }
            ],
            // 提示框
            tooltip: {
                trigger: 'axis'
            },
            color:new echarts.graphic.LinearGradient(
                0, 0, 0, 1,
                [{offset: 0, color: 'rgba(255, 201, 165, 0.71)'},
                    {offset: 1, color: 'rgba(255, 201, 165, 0.02)'}]),
            series: [{
                symbol:'none', //这句就是去掉点的
                smooth:true,
                data: right,
                type: 'line',
                areaStyle: {},
                itemStyle:{
                    normal:{
                        lineStyle:{
                            width:5,  // 设置线宽
                            color:"#FD8245"
                        }
                    }
                }
            }]
        };
    }

    renderDetail(){

        let {data} = this.state;
        let tokens = this.props.redux.tokenList;
        let tokenPath = this.state.tokenPath;
        let token1 = this.getTokensById(tokenPath.length ? tokenPath[tokenPath.length - 1]:this.state.baseToken);
        let token2 = this.getTokensById(tokenPath.length ? tokenPath[0]:this.state.quoteToken);

        let token3 = {};
        if(tokenPath.length > 2)
        {
            token3 = this.getTokensById(tokenPath[1]);
        }

        let baseQuantity = new BigNumber(this.state.getTokenPoolQuantity).toFormat(4);
        let quoteQuantity = new BigNumber(this.state.payTokenPoolQuantity).toFormat(4);

        let fee = 0;
        if(this.state.fees.length)
        {
            fee = new BigNumber(this.state.fees[0]).times(100).toFormat(2);
        }

        let fee2 = 0;
        if(this.state.fees.length > 1)
        {
            fee2 = new BigNumber(this.state.fees[1]).times(100).toFormat(2);
        }

        // let fee = new BigNumber(this.state.fees).times(100).toFormat(2);

        let timeTypes = ['分钟', '小时', '日'];
        let priceTypes = ['价格', '交易额', '交易量'];



        return (
            <div className={'swap-bottom-content'}>
                <div style={{padding:"5.33vw"}}>
                    <p className={'swap-p5'}>兑换路径及手续费用</p>
                    <div className={'flex-display'}>
                        <div className={'flex-center-col'} style={{flex:1}}>
                            <img className={'icon-usdt'} alt="" src={token2.logo}/>
                            <p className={'swap-p5'}>{token2.name}</p>
                        </div>
                        <div className={'flex-display-col'} style={{flex:1, height:"20vw"}}>
                            <p className={'swap-p4'} style={{fontWeight:"bold"}}>{fee}%</p>
                            <img className={'line-dash'} alt="" src={require('../../images/swap/arrow-exchange.png')}/>
                        </div>
                        {token3.name ? <div className={'flex-center-col'} style={{flex:1}}>
                            <img className={'icon-usdt'} alt="" src={token3.logo}/>
                            <p className={'swap-p5'}>{token3.name}</p>
                        </div> : null}
                        {fee2 ? <div className={'flex-display-col'} style={{flex:1, height:"20vw"}}>
                            <p className={'swap-p4'} style={{fontWeight:"bold"}}>{fee2}%</p>
                            <img className={'line-dash'} alt="" src={require('../../images/swap/arrow-exchange.png')}/>
                        </div> : null}
                        <div className={'flex-center-col'} style={{flex:1}}>
                            <img className={'icon-usdt'} alt="" src={token1.logo}/>
                            <p className={'swap-p5'}>{token1.name}</p>
                        </div>
                    </div>
                    <div className={'flex-between'}>
                        <p className={'swap-p5'}>流动性提供者分红费用</p>
                        <p className={'swap-p6'}>手续费的50%</p>
                    </div>
                    <div className={'flex-between'} style={{marginTop:'2vw'}}>
                        <p className={'swap-p5'}>今日累计手续费</p>
                        <div className={'swap-p6'}>{new BigNumber(this.state.buyFee).toFixed(4)} USDT(买盘)</div>
                    </div>
                    <div className={'flex-between'}>
                        <div />
                        <div className={'swap-p6'}>{new BigNumber(this.state.sellFee).toFixed(4)} USDT(卖盘)</div>
                    </div>
                    {this.state.list.length ? <div className={'flex-between'} style={{marginTop:'2vw'}}>
                        <p className={'swap-p5'}>分时走势图</p>
                        <div className={'flex-display'} style={{position:"relative", zIndex:99}}>
                            <Popover mask
                                     overlayClassName="fortest"
                                     overlayStyle={{ color: 'currentColor' }}
                                     visible={this.state.visible}
                                     overlay={[
                                         (<Item key="4" value={0}>
                                             <div className={'btn-sub flex-center'}>
                                                 <p className={'btn-text2'}>分钟</p>
                                             </div>
                                         </Item>),
                                         (<Item key="5" value={1}>
                                             <div className={'btn-sub flex-center'}>
                                                 <p className={'btn-text2'}>小时</p>
                                             </div>
                                         </Item>),
                                         (<Item key="6" value={2}>
                                             <div className={'btn-sub flex-center'}>
                                                 <p className={'btn-text2'}>日</p>
                                             </div>
                                         </Item>),
                                     ]}
                                     align={{
                                         overflow: { adjustY: 0, adjustX: 0 },
                                         offset: [-10, 0],
                                     }}
                                // onVisibleChange={()=>{this.setState({visible:false})}}
                                     onSelect={(opt)=>{
                                         this.setState({
                                             visible: false,
                                             timeType: opt.props.value,
                                         }, ()=>{
                                             this.getPoolInfo();
                                         });
                                     }}
                            >
                                <div className={'btn-sub flex-center'} style={{marginRight:"4vw"}}>
                                    <p className={'btn-text2'}>{timeTypes[this.state.timeType]}</p>
                                    <img className={'btn-arrow'} alt="" src={require('../../images/swap/arrow-down-2.png')}/>
                                </div>
                            </Popover>
                            <Popover mask
                                     overlayClassName="fortest"
                                     overlayStyle={{ color: 'currentColor' }}
                                     visible={this.state.visible2}
                                     overlay={[
                                         (<Item key="4" value={0}>
                                             <div className={'btn-sub flex-center'}>
                                                 <p className={'btn-text2'}>价格</p>
                                             </div>
                                         </Item>),
                                         (<Item key="5" value={1}>
                                             <div className={'btn-sub flex-center'}>
                                                 <p className={'btn-text2'}>交易额</p>
                                             </div>
                                         </Item>),
                                         (<Item key="6" value={2}>
                                             <div className={'btn-sub flex-center'}>
                                                 <p className={'btn-text2'}>交易量</p>
                                             </div>
                                         </Item>),
                                     ]}
                                     align={{
                                         overflow: { adjustY: 0, adjustX: 0 },
                                         offset: [-10, 0],
                                     }}
                                // onVisibleChange={()=>{this.setState({visible2:false})}}
                                     onSelect={(opt)=>{
                                         this.setState({
                                             visible2: false,
                                             priceType: opt.props.value,
                                         }, ()=>{
                                             this.getPoolInfo();
                                         });
                                     }}
                            >
                                <div className={'btn-sub flex-center'}>
                                    <p className={'btn-text2'}>{priceTypes[this.state.priceType]}</p>
                                    <img className={'btn-arrow'} alt="" src={require('../../images/swap/arrow-down-2.png')}/>
                                </div>
                            </Popover>
                        </div>
                    </div> : null}
                </div>
                {this.state.list.length ? <ReactEcharts style={{margin:"-10.33vw 0",  width:"78.7vw", marginLeft:"3.33vw"}} option={this.getOption()} /> : null}
                <div style={{padding:"5.33vw"}}>
                    {this.state.volumeToday ? <div className={'flex-between'}>
                        <p className={'swap-p5'}>今日交易量</p>
                        <p className={'swap-p6'}>{this.state.volumeToday ? BigNumber(this.state.volumeToday).toFormat(4) : '-'}</p>
                    </div> : null}
                    {this.state.totalToday ? <div className={'flex-between'}>
                        <p className={'swap-p5'}>今日交易额</p>
                        <p className={'swap-p6'}>{this.state.totalToday ? BigNumber(this.state.totalToday).toFormat(4) : '-'}</p>
                    </div> : null}
                    <div className={'flex-between'}>
                        <p className={'swap-p5'}>资金池余额</p>
                        <p className={'swap-p6'}>{baseQuantity} {token1.name}</p>
                    </div>
                    <div className={'flex-between'} style={{marginTop:"-4vw"}}>
                        <p className={'swap-p5'} />
                        <p className={'swap-p6'}>{quoteQuantity} {token2.name}</p>
                    </div>
                </div>
            </div>
        )
    }

    ifHasBonus(){

        let {account} = this.props.redux;

        let value = 0;
        for (let i = 0; i < account.bonus.length; i++)
        {
            value += Number(account.bonus[i].quantity);
        }

        return value;
    }

    renderPool(){

        let {account} = this.props.redux;

        return (
            <div style={{padding:"5.33vw"}}>
                {account.share.length === 0 ? <div className={'flex-center-col'} style={{marginBottom:"9.73vw"}}>
                        <img style={{width:"29.87vw", height:"29.87vw"}} alt="" src={require('../../images/swap/pool-empty.png')}/>
                        <div style={{color:"#C1A59A", fontSize:"3.74vw", marginTop:"2.8vw"}}>
                            您还未加入资金池
                        </div>
                    </div>
                :null}
                <div onClick={()=>{this.setState({poolListVisible:true})}} className={'swap-btn flex-center'} style={{margin:"5.33vw 0"}}>
                    <p className={'btn-text'}>加入资金池</p>
                </div>
                {account.share.length ? <div className={'flex-between'}>
                    <p className={'swap-p4'} style={{fontWeight:"bold"}}>您的资金池份额</p>
                    {this.ifHasBonus() ? <div onClick={()=>{this.setState({modal2:true})}} className={'flex-display'}>
                        <img style={{width:"6.13vw", height:"5.33vw", marginRight:"2.53vw"}} alt="" src={require('../../images/swap/reward.png')}/>
                        <p style={{color:"#E15502", fontSize:"3.47vw"}}>领取所有分红</p>
                    </div> : null}
                </div> : null}
                {account.share.length ? <div>
                    {this.state.poolList.map((item, index) => {
                        if(this.getShareById(item.id) !== 0)
                        {
                            return this.renderItem(item, index);
                        }
                    })}
                </div> : null}
            </div>
        )
    }

    renderItem(item, index){

        let token1 = this.getTokensById(item.baseToken);
        let token2 = this.getTokensById(item.quoteToken);
        let token3 = this.getTokensById(item.shareToken);

        let down = this.state.down[index];

        let baseQuantity = new BigNumber(item.baseQuantity);
        let quoteQuantity = new BigNumber(item.quoteQuantity);
        let bonus = new BigNumber(this.getPoolById(item.id).quantity);
        let share = new BigNumber(this.getShareById(item.id).quantity);
        let shareItem = this.getShareById(item.id);
        let bonusItem = this.getPoolById(item.id);

        let total = new BigNumber(item.totalQuantity);

        let ratio = share.div(total).times(100).toFormat(2);

        return (
            <div onClick={()=>{
                down = !down;
                let data = Object.assign({}, this.state.down)
                data[index] = down;
                this.setState({down:data});
            }}>
                <div className={'flex-between'}>
                    <div className={'flex-display'}>
                        <img style={{width:'8.8vw', height:"8.8vw", border: "#fff0e6 2px solid", borderRadius:"50%", marginRight:"-2.53vw", zIndex:2}} alt="" src={token1.logo}/>
                        <img style={{width:'8.8vw', height:"8.8vw", border: "#fff0e6 2px solid", borderRadius:"50%", marginRight:"2.53vw"}} alt="" src={token2.logo}/>
                        <p className={'swap-p7'}>
                            {token1.name}/{token2.name}
                        </p>
                    </div>
                    <img style={{width:"2.4vw", height:"1.33vw"}} alt="" src={down ? require('../../images/swap/arrow-up.png') : require('../../images/swap/arrow-down-2.png')}/>
                </div>
                {down ? <div>
                        {
                            parseFloat(bonusItem.quantity) > 0 ? <div className={'flex-between'} style={{height:"12vw"}}>
                                <p className={'swap-p5'}>
                                    待领取分红
                                </p>
                                <div className={'flex-display-col'}>
                                    <div className={'swap-p7'}>
                                        {new BigNumber(bonusItem.xcnQuantity).toFixed(4, 1)} {token1.name}
                                    </div>
                                    <div className={'swap-p7'}>
                                        {bonus.toFixed(4, 1)} {token2.name}
                                    </div>
                                </div>
                                {/*<p className={'swap-p7'}>*/}
                                {/*    {bonus.toFormat(4)}*/}
                                {/*</p>*/}
                            </div> : null
                        }
                        <div className={'flex-between'} style={{height:"8vw"}}>
                            <p className={'swap-p5'}>
                                个人资金池份额
                            </p>
                            <p className={'swap-p7'}>
                                {share.toFixed(4, 1)}
                            </p>
                        </div>
                        <div className={'flex-between'} style={{height:"8vw"}}>
                            <p className={'swap-p5'}>
                                个人份额占比
                            </p>
                            <p className={'swap-p7'}>
                                {ratio}%
                            </p>
                        </div>
                        <div className={'flex-between'} style={{height:"8vw"}}>
                            <p className={'swap-p5'}>
                                资金池{token1.name}
                            </p>
                            <p className={'swap-p7'}>
                                {baseQuantity.toFixed(4)}
                            </p>
                        </div>
                        <div className={'flex-between'} style={{height:"8vw"}}>
                            <p className={'swap-p5'}>
                                资金池{token2.name}
                            </p>
                            <p className={'swap-p7'}>
                                {quoteQuantity.toFixed(4)}
                            </p>
                        </div>
                        <div className={'flex-between'} style={{marginTop:"4vw"}}>
                            <div onClick={()=>{this.setState({poolVisible:true, poolId:item.id})}} className={'pool-btn flex-center'}>
                                <p className={'swap-p4'} style={{color:"#FF700E"}}>追加份额</p>
                            </div>
                            <div onClick={()=>{this.setState({poolExitVisible:true, poolId:item.id})}} className={'pool-btn flex-center'}>
                                <p className={'swap-p4'} style={{color:"#FF700E"}}>退出份额</p>
                            </div>
                        </div>
                    </div>
                    : <div>
                        {
                            parseFloat(bonusItem.quantity) > 0 ? <div className={'flex-between'} style={{height:"12vw"}}>
                                <p className={'swap-p5'}>
                                    待领取分红
                                </p>
                                <div className={'flex-display-col'}>
                                    <div className={'swap-p7'}>
                                        {parseFloat(bonusItem.xcnQuantity).toFixed(4)} {token1.name}
                                    </div>
                                    <div className={'swap-p7'}>
                                        {bonus.toFormat(4)} {token2.name}
                                    </div>
                                </div>
                                {/*<p className={'swap-p7'}>*/}
                                {/*    {bonus.toFormat(4)}*/}
                                {/*</p>*/}
                            </div> : null
                        }
                    </div>}
            </div>
        )
    }

    render() {

        let tab = this.state.tab;

        let tokens = this.props.redux.tokenList;

        // let bonus = new BigNumber(this.getPoolById(item.id).quantity);
        // let share = new BigNumber(this.getShareById(item.id).quantity);
        // let shareItem = this.getShareById(item.id);
        // let bonusItem = this.getPoolById(item.id);

        let {account} = this.props.redux;
        let quantity = 0;
        let xcnQuantity = 0;
        if(account.bonus.length)
        {
            quantity = account.bonus[0].quantity;
            xcnQuantity = account.bonus[0].xcnQuantity;
        }
        let fee = 0;
        if(account.contractFee.length > 1)
        {
            fee = account.contractFee[1].quantity;
        }

        let rewardUsdt = new BigNumber(quantity).minus(fee).toFixed(4,1);
        if(rewardUsdt < 0)
        {
            rewardUsdt = 0;
        }

        //todo



        return (
            //style={{overflow:"hidden"}}

            <div className="page swap">
                <div className={'swap-p1'} style={{textAlign:"center", marginTop:"2.67vw"}}>
                    首次分红时间为次日24:00
                </div>
                {/*<SystemMaintanance />*/}
                <Modal
                    visible={this.state.modal2}
                    transparent
                    maskClosable={true}
                    onClose={()=>{this.setState({modal2:false})}}
                    // footer={[{ text: 'Ok', onPress: () => { console.log('ok'); this.onClose('modal1')(); } }]}
                >
                    <div className={'flex-center-col'}>
                        <div style={{ color:"#221814", fontSize:"4vw", lineHeight:"6.4vw", marginBottom:"5.33vw"}}>
                            您正在领取流动资金池分红
                        </div>
                        <div className={'flex-between'} style={{width:"66.7vw"}}>
                            <div style={{ color:"#221814", fontSize:"4vw", lineHeight:"6.4vw"}}>
                                领取分红数量：
                            </div>
                            <div className={'flex-end-col'}>
                                <div style={{ color:"#221814", fontSize:"4vw", lineHeight:"6.4vw"}}>
                                    {xcnQuantity} XCN
                                </div>
                                <div style={{ color:"#221814", fontSize:"4vw", lineHeight:"6.4vw"}}>
                                    {quantity} USDT
                                </div>
                            </div>
                        </div>
                        <div className={'flex-between'} style={{width:"66.7vw"}}>
                            <div style={{ color:"#221814", fontSize:"4vw", lineHeight:"6.4vw"}}>
                                合约服务费：
                            </div>
                            <div style={{ color:"#221814", fontSize:"4vw", lineHeight:"6.4vw"}}>
                                {fee} USDT
                            </div>
                        </div>
                        <div className={'flex-between'} style={{width:"66.7vw"}}>
                            <div style={{ color:"#221814", fontSize:"4vw", lineHeight:"6.4vw"}}>
                                预计到账数量：
                            </div>
                            <div className={'flex-end-col'}>
                                <div style={{ color:"#221814", fontSize:"4vw", lineHeight:"6.4vw"}}>
                                    {xcnQuantity} XCN
                                </div>
                                <div style={{ color:"#221814", fontSize:"4vw", lineHeight:"6.4vw"}}>
                                    {rewardUsdt} USDT
                                </div>
                            </div>
                        </div>
                        <div onClick={()=>{this.setState({modal2:false}, ()=>{this.getReward()})}} style={{width:"60vw", height:"9.33vw", backgroundColor:"#FD8245", borderRadius:"2.13vw", lineHeight:"9.33vw", textAlign:"center",
                            color:"white", fontSize:"4vw", marginTop:"6.53vw"}}>
                            继续领取
                        </div>
                    </div>
                </Modal>
                <Modal
                    visible={this.state.modal1}
                    transparent
                    maskClosable={false}
                    onClose={()=>{this.setState({modal1:false})}}
                    // footer={[{ text: 'Ok', onPress: () => { console.log('ok'); this.onClose('modal1')(); } }]}
                >
                    <div className={'flex-center-col'}>
                        <div style={{ color:"#221814", fontSize:"4vw", lineHeight:"6.4vw"}}>
                            兑换须知：
                            因链上价格可能会随时产生波动，所以您兑换到手的数量可能与实际目标兑换数量存在偏差。
                        </div>
                        <div onClick={()=>{this.setState({modal1:false})}} style={{width:"60vw", height:"9.33vw", backgroundColor:"#FD8245", borderRadius:"2.13vw", lineHeight:"9.33vw", textAlign:"center",
                            color:"white", fontSize:"4vw", marginTop:"6.53vw"}}>
                            我已了解
                        </div>
                    </div>
                </Modal>
                <Modal
                    visible={this.state.modal3}
                    transparent
                    maskClosable={false}
                    onClose={()=>{this.setState({modal3:false})}}
                    // footer={[{ text: 'Ok', onPress: () => { console.log('ok'); this.onClose('modal1')(); } }]}
                >
                    <div className={'flex-center-col'}>
                        <div style={{ color:"#221814", fontSize:"4vw", lineHeight:"6.4vw"}}>
                            MDC余额不足以支持手续费，请先充币哦~
                        </div>
                        <div onClick={()=>{this.setState({modal3:false})}} style={{width:"60vw", height:"9.33vw", backgroundColor:"#FD8245", borderRadius:"2.13vw", lineHeight:"9.33vw", textAlign:"center",
                            color:"white", fontSize:"4vw", marginTop:"6.53vw"}}>
                            去充币
                        </div>
                    </div>
                </Modal>
                <Modal
                    visible={this.state.modal4}
                    transparent
                    maskClosable={false}
                    onClose={()=>{this.setState({modal4:false})}}
                    // footer={[{ text: 'Ok', onPress: () => { console.log('ok'); this.onClose('modal1')(); } }]}
                >
                    <div className={'flex-center-col'}>
                        <div style={{ color:"#221814", fontSize:"4vw", lineHeight:"6.4vw"}}>
                            待领取分红数量低于合约服务费，无法领取！
                            当前合约服务费为：{fee} USDT
                        </div>
                        <div onClick={()=>{this.setState({modal4:false})}} style={{width:"60vw", height:"9.33vw", backgroundColor:"#FD8245", borderRadius:"2.13vw", lineHeight:"9.33vw", textAlign:"center",
                            color:"white", fontSize:"4vw", marginTop:"6.53vw"}}>
                            我知道了
                        </div>
                    </div>
                </Modal>
                {this.state.poolVisible ? <ModalPool pool={this.getPoolListById(this.state.poolId)} visible={this.state.poolVisible} onClose={()=>{this.setState({poolVisible:false})}}/> : null}
                {this.state.poolExitVisible ? <ModalPoolExit pool={this.getPoolListById(this.state.poolId)} visible={this.state.poolExitVisible} onClose={()=>{this.setState({poolExitVisible:false})}} /> : null}
                {this.state.poolAddVisible ? <ModalPoolAdd visible={this.state.poolAddVisible} onClose={()=>{this.setState({poolAddVisible:false})}} /> : null}
                <ModalPoolList visible={this.state.poolListVisible}
                               poolList={this.state.poolList}
                               onSelect={(id)=>{
                                   this.setState({poolId:id, poolListVisible:false, poolVisible:true})
                               }}
                               onClose={()=>{this.setState({poolListVisible:false})}} />
                <ModalTokenList
                    onSelect={(token)=>{
                        this.setState({baseToken:token, tokenListVisible:false, exchangeAmount:0, payAmount:0}, ()=>{
                            this.getPoolInfo(0);
                        });
                    }}
                    type={0}
                    baseToken={this.state.baseToken}
                    quoteToken={this.state.quoteToken} visible={this.state.tokenListVisible} onClose={()=>{this.setState({tokenListVisible:false})}}/>
                <ModalTokenList
                    onSelect={(token)=>{
                        this.setState({quoteToken:token, tokenListVisible2:false, exchangeAmount:0, payAmount:0}, ()=>{
                            this.getPoolInfo(0);
                        });
                    }}
                    type={1}
                    baseToken={this.state.quoteToken}
                    quoteToken={this.state.baseToken} visible={this.state.tokenListVisible2} onClose={()=>{this.setState({tokenListVisible2:false})}}/>
                <div className={'swap-header'}>
                    <img className={'icon-logo'} alt="" src={require('../../images/swap/logo.png')}/>
                    <div className={'flex-display-col'}>
                        <div className={'flex-display'}>
                            <img className={'icon-avatar'} alt="" src={require('../../images/swap/avatar.png')}/>
                            <p className={'swap-p1'} style={{width:"41.07vw", textOverflow:'ellipsis', overflow:"hidden", whiteSpace:"nowrap", height:"3.47vw"}}>
                                您的地址：{this.props.redux.address || '-'}
                            </p>
                        </div>
                        <div className={'flex-between'}>
                            <Popover mask
                                     overlayClassName="fortest"
                                     overlayStyle={{ color: 'currentColor' }}
                                     visible={this.state.visible}
                                     onVisibleChange={()=>{this.setState({visible:false})}}
                                     overlay={[
                                         (<Item key="4" value={0}>
                                             <div className={'btn-sub flex-center'}>
                                                 <p className={'btn-text2'}>兑换记录</p>
                                             </div>
                                         </Item>),
                                         (<Item key="5" value={1}>
                                             <div className={'btn-sub flex-center'}>
                                                 <p className={'btn-text2'}>份额记录</p>
                                             </div>
                                         </Item>),
                                         (<Item key="6" value={2}>
                                             <div className={'btn-sub flex-center'}>
                                                 <p className={'btn-text2'}>分红记录</p>
                                             </div>
                                         </Item>),
                                     ]}
                                     align={{
                                         overflow: { adjustY: 0, adjustX: 0 },
                                         offset: [-10, 0],
                                     }}
                                     onSelect={(opt)=>{
                                         if(opt.props.value === 0)
                                         {
                                             this.props.history.push(`/records`);
                                         } else if(opt.props.value === 1)
                                         {
                                             this.props.history.push(`/shareRecords`);
                                         } else if(opt.props.value === 2)
                                         {
                                             this.props.history.push(`/rewardRecords`);
                                         }

                                         //this.props.history.push(`/records`)

                                         // this.setState({
                                         //     visible: false,
                                         //     timeType: opt.props.value,
                                         // }, ()=>{
                                         //     this.getPoolInfo();
                                         // });
                                     }}
                            >
                                <div className={'swap-header-btn flex-between'} style={{marginRight:"2.1vw"}}>
                                    <img className={'icon-btn'} alt="" src={require('../../images/swap/record.png')}/>
                                    <div className={'swap-p1'}>记录</div>
                                    <img className={'icon-down-arrow'} alt="" src={require('../../images/swap/arrow-down.png')}/>
                                </div>
                            </Popover>
                            <div onClick={()=>{
                                this.props.history.push(`/platform`)
                            }} className={'swap-header-btn flex-between'}>
                                <img className={'icon-btn'} alt="" src={require('../../images/swap/data.png')}/>
                                <p className={'swap-p1'}>平台数据</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div className={'swap-content'}>
                    <div className={'flex-display'} style={{position:"relative", height:"12.9vw"}}>
                        <div className={tab ? 'tab-un-select2 pos1 flex-center' : 'tab-selected pos1 flex-center'} onClick={()=>this.setState({tab:0})}>
                            <p className={tab ? 'select-off-text' : 'select-text'}>
                                兑换
                            </p>
                        </div>
                        <div className={!tab ? 'tab-un-select pos2 flex-center' : 'tab-selected2 pos2 flex-center'} onClick={()=>this.setState({tab:1})}>
                            <p className={!tab ? 'select-off-text' : 'select-text'}>
                                资金池
                            </p>
                        </div>
                    </div>
                    {this.state.tab === 0 ? this.renderExchange():this.renderPool()}
                </div>
                {this.state.tab === 0 && this.state.poolList.length && tokens.length ? this.renderDetail():null}
            </div>
        );
    }
}

export default connect(Swap);
