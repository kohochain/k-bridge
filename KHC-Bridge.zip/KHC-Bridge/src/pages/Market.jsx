import React, {Component} from "react";


class Market extends Component {

    constructor(props){
        super(props);
        this.state = {
            list:[],
        }
    }

    componentDidMount(){

    }

    render() {

        const height = window.screen.height >= 812 ? (window.screen.height - 50) : (812 - 50);

        const height2 = window.screen.height - 50;

        return (
            <div className={'page'} style={{overflow:'hidden', height:height2 + "px", position:"relative"}}>
                <img alt="" style={{position:"absolute", width:'77.6vw', height:'100.32vw', top:'20vh', left:"12vw"}} src={require('../images/market/toast.png')} />
                <img alt="" style={{width:"100vw", height:height}} src={require('../images/market/market.png')} />
            </div>
        )
    }
}

export default Market;
