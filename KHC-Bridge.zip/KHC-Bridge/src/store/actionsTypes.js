export const SET_ADDRESS = 'SET_ADDRESS';

export const UPDATE_BALANCE = 'UPDATE_BALANCE';

export const SET_DEVICE = 'SET_DEVICE';

export const SET_FEE = 'SET_FEE';

export const SET_ACTIVE = 'SET_ACTIVE';

export const TAB = 'TAB';

export const SET_TOKENLIST = 'SET_TOKENLIST';

export const SET_ACCOUNT = 'SET_ACCOUNT';

export const SET_BALANCE = 'SET_BALANCE';

export const SET_PT_BALANCE = 'SET_PT_BALANCE';

