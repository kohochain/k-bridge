import * as actionsTypes from './actionsTypes';

export const setAddress = data => ({ type: actionsTypes.SET_ADDRESS, data });

export const updateBalance = data => ({ type: actionsTypes.UPDATE_BALANCE, data });

export const setDevice = data => ({ type: actionsTypes.SET_DEVICE, data });

export const setFee = data => ({ type: actionsTypes.SET_FEE, data });

export const setActive = data => ({ type: actionsTypes.SET_ACTIVE, data });

export const setTab = data => ({ type: actionsTypes.TAB, data });

export const setTokenList = data => ({ type: actionsTypes.SET_TOKENLIST, data });

export const setAccount = data => ({ type: actionsTypes.SET_ACCOUNT, data });

export const setBalance = data => ({ type: actionsTypes.SET_BALANCE, data });

export const setPtBalance = data => ({ type: actionsTypes.SET_PT_BALANCE, data });
//setBalance


