import { get, post } from './method';

const pre = '/exchange';

export default {
    // 获取信息
    getExchangeConfig: data => get(`${pre}/access/config`, data),

    // 获取地址
    getExchangeAddress: data => post(`${pre}/address`, data),
}