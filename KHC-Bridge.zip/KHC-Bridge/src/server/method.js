
const handleErr = (err) => {
	if (err.message === 'Failed to fetch') {
		return { response_msg: '网络错误' }
	} else {
		return { response_msg: '服务不可用' }
	}
}

const doGetFetch = url => {
	const urlParam = {};
    if(Storage.signToken) {
        urlParam.address = Storage.signToken.address;
        urlParam.timestamp = Storage.signToken.timestamp;
        urlParam.signature = Storage.signToken.signature;
    }

    if(localStorage.getItem('address')){
		urlParam.address = localStorage.getItem('address');
	}

	return new Promise((resolve, reject) => {
		fetch(''+url, {
			method: "GET",
			credentials: "include",
			headers: {
				...urlParam,
			}
		})
			.then(response => response.json())
			.then(res => resolve(res))
			.catch(err => {reject(err)});
	});
};

const doPostFetch = (url, jsondata) => {

	return new Promise((resolve, reject) => {
		fetch(''+url, {
			method: "POST",
			headers: {
				Accept: "application/json",
				"Content-Type": "application/json",
				address: localStorage.getItem('address') || ""
			},
			credentials: "include",
			body: JSON.stringify(jsondata)
		})
			.then(response => response.json())
			.then(res => resolve(res))
			.catch(err => reject(err));
	});
};

const doFormFetch = (url, jsondata) => {
	let paramsArray = '';

	if (jsondata) {
		Object
			.keys(jsondata)
			.forEach(key => paramsArray += (key + "=" + jsondata[key] + "&"));
	}

	return new Promise((resolve, reject) => {
		fetch(''+url, {
			method: "POST",
			credentials: "include",
			headers: {
				'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8',
				address: localStorage.getItem('address') || ""
			},
			body: paramsArray
		})
			.then(response => response.json())
			.then(res => resolve(res))
			.catch(err => reject(err));
	});
};

export const get = async (url, params) => {
	if (params) {
		let paramsArray = [];
		Object
			.keys(params)
			.forEach(key => paramsArray.push(key + "=" + params[key]));
		if (url.search(/\?/) === -1) {
			url += "?" + paramsArray.join("&");
		} else {
			url += "&" + paramsArray.join("&");
		}
	}
	try {
		return await doGetFetch(url);
	} catch (e) {
		return handleErr(e)
	}
};

export const post = async (url, params) => {
	if (params && localStorage.getItem('token')) {
		params.authtoken = localStorage.getItem('token');
	}
	try {
		return await doPostFetch(url, params);
	} catch (e) {
		return handleErr(e)
	}
};

export const form = async (url, params) => {
	try {
		return await doFormFetch(url, params);
	} catch (e) {
		return handleErr(e)
	}
};
