import { get, post } from './method';

export default {
    // 当期拼团信息
    getMyBalance: data => get(`/my/balance`, data),

    //查询当前hash情况
    getMyDepositHash: data => get(`/my/deposit/hash`, data),
}
