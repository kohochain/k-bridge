import Web3 from "web3";

export function getKHCAddress () {
    if(window.KHCExtension)
    {
        return window.KHCExtension.defaultAddress.base58;
    }
    else {
        return null;
    }
}

export async function getETHAddress () {

    if(window.ethereum)
    {
        const result = await window.ethereum.request({method:'eth_accounts'});

        if(result.length)
        {
            return result[0];
        }

        return null;
    }

    return null;
}

export function getTRXAddress () {
    if(window.tronWeb)
    {
        return window.tronWeb.defaultAddress.base58;
    }
    else {
        return null;
    }
}

export async function getBSCAddress(){
    if(window.BinanceChain)
    {

        const web3 = new Web3(window.BinanceChain);
        const accounts = await web3.eth.requestAccounts();

        if(accounts.length)
        {
            return accounts[0];
        }

        return null;
    }
    else if(window.ethereum)
    {
        const networkVersion = await window.ethereum.request({method:'net_version'});

        if(Number(networkVersion) === 56)
        {
            const eth = await getETHAddress();
            return eth;
        }
    }

    return null;
}

export function getBitKeepAccount(){
    if(window.__bitkeepAccount)
    {
        return window.__bitkeepAccount;
    }

    return null;
}

export function getBitKeepKHC(){
    if(window.__bitkeepAccount && window.__bitkeepAccount.khc)
    {
        return window.__bitkeepAccount.khc.address;
    }

    return null;
}

export function getBitKeepTRX(){
    if(window.__bitkeepAccount && window.__bitkeepAccount.trx)
    {
        return window.__bitkeepAccount.trx.address;
    }

    return null;
}

export function getBitKeepETH(){
    if(window.__bitkeepAccount && window.__bitkeepAccount.eth)
    {
        let address = null;
        window.__bitkeepAccount.eth.map((item, index)=>{
            if(item.chainName === 'eth')
            {
                address = item.address;
            }
        });

        return address;
    }

    return null;
}

export function getBitKeepBSC(){
    if(window.__bitkeepAccount && window.__bitkeepAccount.eth)
    {
        let address = null;
        window.__bitkeepAccount.eth.map((item, index)=>{
            if(item.chainName === 'bnb')
            {
                address = item.address;
            }
        });

        return address;
    }

    return null;
}