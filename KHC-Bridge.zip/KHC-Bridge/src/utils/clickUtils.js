import {post } from '../server/method';

const address = 'https://click.khchain.io';

// URL参数处理方法
const urlHandle = () => {
    try {
        const { href } = window.location;
        const result = {};
        if (href.indexOf('?') > -1) {
            const params = href.split('?')[1].split('#')[0];

            const paramList = params.split('&');

            paramList.forEach((item) => {
                const [key, value] = item.split('=');

                result[key] = value;
            });
        }
        return result;
    } catch (E) {
        return {}
    }
}


// 本地用户唯一标识的生成和维护
const generateUID = () => {
    let uid = localStorage.getItem('uid');

    if (!uid) {
        const temp_url = URL.createObjectURL(new Blob());
        const uuid = temp_url.toString();
        URL.revokeObjectURL(temp_url);
        uid = uuid.substr(uuid.lastIndexOf("/") + 1);
        localStorage.setItem('uid', uid);
    }

    return uid;
}

// 上传信息配置
const clickConfig = {
    aliveInterval: 10000, // 单位是毫秒,
    appName: 'magicbridge', // 应用名称
    version: '1.0', // 应用版本号，
    platform: (window.innerWidth <= 900) ? 'h5' : 'web', // 平台判断
}

// // 信息上传的方法
// export const saveClick = (clickId, params) => {
//     post(address + '/click/click', {
//         clickId,
//         params: JSON.stringify(params),
//         uid: generateUID(),
//         createTime: new Date(),
//         appName: clickConfig.appName,
//         platform: clickConfig.platform,
//         version: clickConfig.version,
//         deviceInfo: clickId === 'START' ? navigator.userAgent : '',
//     }).then()
// }


// 信息上传的方法
export const saveClick = (clickId, params) => {

    if(window.MDCExtension)
    {
        params.address = window.MDCExtension.defaultAddress.base58;
    }

    post(address + '/click/click', {
        clickId,
        params: JSON.stringify(params),
        uid: generateUID(),
        createTime: new Date(),
        appName: clickConfig.appName,
        platform: clickConfig.platform,
        version: clickConfig.version,
        deviceInfo: clickId === 'START' ? navigator.userAgent : '',
    }).then()
}

// 打开应用就上传一次信息
saveClick('START', urlHandle());

// 心跳保持，上传参数是页面路径
setInterval(() => saveClick('ALIVE', {uri: window.location.pathname}), clickConfig.aliveInterval)

