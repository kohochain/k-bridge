import BigNumber from "bignumber.js";

export function checkValue(value, number, mode) {
    if(value === undefined || value === null || isNaN(value) || value === 'NaN')
    {
        return "-"
    }

    if(mode === 2)
    {
        return value;
    }

    return new BigNumber(value).toFixed(number === undefined || number === null ? 4 : number, mode);
}

export function getValue(value, number, mode)
{
    return checkValue(value, number, mode ? 0 : mode);
}

export function getGuarantee(value){
    return checkValue(value, 0, 3);
}

export function getRate(value, num = 2){
    if(value === undefined || value === null)
        return "-";

    return parseFloat(value * 100).toFixed(num) + "%";
}

export function getRound(value, num = 4){

    if(value === undefined || value === null)
        return 0;

    return Math.floor(value * Math.pow(10, num)) / Math.pow(10, num)
}

export function fromDecimals(value, num = 4){

    if(value === undefined || value === null)
        return 0;

    return new BigNumber(value).div(Math.pow(10, num)).toFixed(4, 1);
}

export function toDecimals(value, num = 4){

    if(value === undefined || value === null)
        return 0;

    return new BigNumber(value).times(Math.pow(10, num));
}

export function getSubStr (str){
    let subStr1 = str. substr( 0, 10);
    let subStr2 = str. substr( str. length- 5, 5);
    let subStr = subStr1 + "..." + subStr2 ;
    return subStr;
}

export function hiddenStr (str, start = 2, end = 2) {
    if(!str || str === "")
        return "";

    let k1 = str.substr(0,start);
    let k2 = str.substr(str.length - end, end);

    return k1 + "****" + k2;
}

export function isNullObject(object) {

    if(object === null || object === undefined)
        return true;
    if(JSON.stringify(object) === '{}')
        return true;
    return false;
}
