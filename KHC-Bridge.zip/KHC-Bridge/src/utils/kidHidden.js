export default function kidHidden(kid) {
    if(!kid || kid === "")
        return "";

    let k1 = kid.substr(0,4);
    let k2 = kid.substr(kid.length - 5, 5);

    return k1 + "...." + k2;
}

export function addressHidden(address, start = 10, end = 10) {
    if(!address || address === "")
        return "";

    let k1 = address.substr(0,start);
    let k2 = address.substr(address.length - end, end);

    return k1 + "...." + k2;
}
