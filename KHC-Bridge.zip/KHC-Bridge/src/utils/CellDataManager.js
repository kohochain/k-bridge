import net from "../server";
import {Toast} from 'antd-mobile';
import {count} from "echarts/src/component/dataZoom/history";
import moment from "moment";

function CellDataManager(item, callback) {//定义一个类
    // 类中创建了一个init的对像,(实例化出来的对象拥有prototype)
    // return new CellDataManager.prototype.init(item, callback);
    this.item = item;
    this.callback = callback;
    this.flag = false;
    this.index = -1; //-1为未开奖
    this.count = 0;
}

CellDataManager.prototype = {
    // 构造函数赋值
    constructor: CellDataManager,
    contents:[],
    // 新增方法
    // init: function (item, callback) {
    //     this.item = item;
    //     this.callback = callback;
    //     this.timer = setInterval(()=>{
    //         callback('111');
    //     }, 3000);
    //     this.dealloc = function () {
    //         if (this.timer) {
    //             clearTimeout(this.timer) && (this.timer = null)
    //         }
    //     }
    // },
    setTimer:function () {
        this.timer = setInterval(()=>{
            this.callback('111');
        }, 3000);
    },
    dealloc: function () {
        if (this.timer) {
            clearTimeout(this.timer) && (this.timer = null)
        }
        if (this.openTimer) {
            clearTimeout(this.openTimer) && (this.openTimer = null)
        }
        if (this.nextTimer)
        {
            clearTimeout(this.nextTimer) && (this.nextTimer = null)
        }
        if (this.startTimer)
        {
            clearTimeout(this.startTimer) && (this.startTimer = null)
        }
    },

    start:function (startTime, callback) {

        if(!this.startTimer && startTime > moment().valueOf())
        {
            this.startTimer = setInterval(()=>{

                if(startTime - moment().valueOf() <= 0)
                {
                    if (this.startTimer)
                    {
                        clearTimeout(this.startTimer) && (this.startTimer = null)
                    }
                    callback(0);
                }
                else {
                    callback(startTime - moment().valueOf());
                }
            }, 1000);
        }
    },

    stop(){
        if (this.startTimer)
        {
            clearTimeout(this.startTimer) && (this.startTimer = null)
        }
    },

    open:function (luckyNum, callback, endCallback) {
        this.dealloc()
        this.index = 0;
        this.openCallBack = callback;
        if(!this.openTimer)
        {
            this.openTimer = setInterval(()=>{
                let value = (this.index + 1)%6;
                this.index = value;
                this.openCallBack(value);
                this.count ++;
                if(this.count >= 6 && this.index === luckyNum)
                {
                    endCallback();
                    this.dealloc();
                }
            }, 500);
        }
    },
    next:function (endTime, callback) {

        if(!this.nextTimer && endTime > moment().valueOf())
        {
            this.nextTimer = setInterval(()=>{

                console.log("end", endTime - moment().valueOf());

                if(endTime - moment().valueOf() <= 0)
                {
                    callback(0);
                    this.dealloc();
                }
                else {
                    callback(endTime - moment().valueOf());
                }
            }, 1000);
        }
    }
};

export default CellDataManager;
