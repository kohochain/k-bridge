import ksdtContractInfo from '../lib/msdtContract';
import khcContractInfo from "../lib/khcContract";
import exchangeContractInfo from "../lib/exchangeContract";
import ethContractInfo from '../lib/KhcExchangeOtherChainToKHC';
import ERC20Contract from '../lib/ERC20Contract.json'
import Web3 from 'web3';
import {Toast} from "antd-mobile";
import intl from "react-intl-universal";

let KHCExtension = window.KHCExtension;
let Contract = null;

const khcContractAddress = process.env.REACT_APP_KHC_ADDRESS;
const ksdtContractAddress = process.env.REACT_APP_USDT_ADDRESS;
const vdsContractAddress = process.env.REACT_APP_VDS_ADDRESS;
const exchangeContractAddress = process.env.REACT_APP_EXCHANGE_ADDRESS;
const eth_khc_ContractAddress = process.env.REACT_APP_ETH_KHC_ADDRESS;
const uni_khc_ContractAddress = process.env.REACT_APP_UNI_KHC_ADDRESS;

const interval = setInterval(async () => {
    KHCExtension = window.KHCExtension;
    if (!KHCExtension) return;
    if (KHCExtension) {
        ksdtContractInfo.contract_address = KHCExtension.address.toHex(ksdtContractAddress);
        exchangeContractInfo.contract_address = KHCExtension.address.toHex(exchangeContractAddress);
        // contractInfo.contract_address = KHCExtension.address.toHex(contractAddress);
        // purchaseContractInfo.contract_address = KHCExtension.address.toHex(purchaseContract);
        // depositContractInfo.contract_address = KHCExtension.address.toHex(depositContract);
        // rewardContractInfo.contract_address = KHCExtension.address.toHex(rewardContract);
        // exchangeContractInfo.contract_address = KHCExtension.address.toHex(exchangeContract);
        khcContractInfo.contract_address = KHCExtension.address.toHex(khcContractAddress);

        clearInterval(interval);
        // await getContract();
    }
}, 1000);


export function getAddress() {
    if (KHCExtension && KHCExtension.defaultAddress) {
        return KHCExtension.defaultAddress.base58
    } else {
        return ''
    }
}

// const getContract = async () => {
//     if (Contract) return;
//     try {
//         // Contract = await KHCExtension.contract().at(contractAddress)
//         Contract = await KHCExtension.contract(contractInfo.abi.entrys, contractInfo.contract_address);
//     } catch (err) {
//         await getContract()
//     }
// };

// const get20Contract = async (contractAddress) => {
//     if (Contract) return;
//     try {
//         // Contract = await KHCExtension.contract().at(contractAddress)
//         Contract = await KHCExtension.contract(msdtContractInfo.abi.entrys, contractAddress);
//     } catch (err) {
//         await getContract()
//     }
// };

export function checkAddress() {
    if (!KHCExtension) {
        return { success: false, message: '请先安装 KHCExtension 插件' }
    } else if (!KHCExtension.defaultAddress) {
        return { success: false, message: '请先创建钱包或者解锁插件' }
    } else {
        return { success: true, address: KHCExtension.defaultAddress.base58 }
    }
}

export async function signTimestamp() {
    const timestamp = parseInt(new Date().getTime() / 1000, 10);
    const signature = `0x${timestamp.toString(16)}`;
    const params = {
        timestamp:timestamp,
        address: KHCExtension.defaultAddress.base58,
        // signature:timestamp
    };

    try {
        params.sign = await KHCExtension.khc.sign(signature);

        return params;

    } catch (e) {
        console.warn(e);
        return false;
    }
}

export function signSimulate() {
    const timestamp = parseInt(new Date().getTime() / 1000, 10);
    const signature = `0x${timestamp.toString(16)}`;
    return {
        timestamp: timestamp,
        address: KHCExtension.defaultAddress.base58,
        sign: signature
    };
}

export async function getBalance() {
    const result = await KHCExtension.khc.getUnconfirmedAccount(KHCExtension.defaultAddress.base58);
    let balance = Number(KHCExtension.fromKoho(result.balance));
    balance = (Math.floor(balance * 10000) / 10000).toFixed(4)
    return Number(balance)
}


export async function get20BalanceResult() {
    let result = await KHCExtension.contract(ksdtContractInfo.abi.entrys, ksdtContractInfo.contract_address);
    const res = await result.balanceOf(KHCExtension.defaultAddress.base58).call();
    let temp_20 = window.KHCExtension.toDecimal(res);
    let balance_20 = (Math.floor(Number(window.KHCExtension.fromKoho(temp_20)) * 10000) / 10000).toFixed(4);
    balance_20 = Number(balance_20)
    return balance_20
}

export async function getVDSBalance(){
    return await getM20BalanceResult(vdsContractAddress);
}

export async function getM20BalanceResult(address) {

    let result = await KHCExtension.contract(ksdtContractInfo.abi.entrys, address);
    const res = await result.balanceOf(KHCExtension.defaultAddress.base58).call();

    let temp_20 = window.KHCExtension.toDecimal(res);
    let balance_20 = (Math.floor(Number(window.KHCExtension.fromKoho(temp_20)) * 10000) / 10000).toFixed(4);
    balance_20 = Number(balance_20)

    return balance_20
}

export async function getK20Contract(address) {
    return await KHCExtension.contract(ksdtContractInfo.abi.entrys, address);
}

export async function getExchangeContract() {
    return await KHCExtension.contract(exchangeContractInfo.abi.entrys, exchangeContractAddress);
}

export async function initWeb3(){
    let web3 = '';
    if(window.ethereum){
        web3 = new Web3(window.ethereum);
        //申请网页连接权限
        await window.ethereum.enable();
    }
    else if(window.web3)
    {
        web3 = new Web3(window.web3.currentProvider);
    }
    else if(window.BinanceChain)
    {
        web3 = new Web3(window.BinanceChain);
    }

    return web3
}

export async function initBscWeb3(){
    let web3 = '';
    if(window.BinanceChain)
    {
        web3 = new Web3(window.BinanceChain);
    } else if(window.ethereum){

        web3 = new Web3(window.ethereum);
        //申请网页连接权限
        await window.ethereum.enable();
    }

    return web3;
}

export async function getETHContract(address){
    let web3 = await initWeb3();
    let myContract = new web3.eth.Contract(ethContractInfo.abi, address);
    return myContract;
}

export async function getBSCContract(address){
    let web3 = await initBscWeb3();
    let myContract = new web3.eth.Contract(ethContractInfo.abi, address);
    return myContract;
}

export async function getERC20Contract(address){
    let web3 = await initWeb3();
    let myContract = new web3.eth.Contract(ERC20Contract, address);
    return myContract;
}

export async function getRC20Contract(address){
    let web3 = await initBscWeb3();
    let myContract = new web3.eth.Contract(ERC20Contract, address);
    return myContract;
}

export async function getERC20Balance(address, contract_address) {
    const contract = await getERC20Contract(contract_address);
    return await contract.methods.balanceOf(address).call();
}

export async function getRC20Balance(address, contract_address) {
    const contract = await getRC20Contract(contract_address);
    return await contract.methods.balanceOf(address).call();
}

export async function getTRC20Contract(address){
    return await window.tronWeb.contract(ksdtContractInfo.abi.entrys, address);
}

export async function getTRXContract(address){
    return await window.tronWeb.contract(ethContractInfo.abi, address);
}

export async function getTRC20Balance(address, contract_address) {

    // const result = await window.tronWeb.trx.getUnconfirmedAccount(window.tronWeb.defaultAddress.base58);
    // let balance = Number(window.tronWeb.fromSun(result.balance));
    // balance = (Math.floor(balance * 10000) / 10000).toFixed(4)
    // alert(balance);

    const contract = await getTRC20Contract(contract_address);
    return await contract.balanceOf(address).call();
}

export function checkTrxHash(hash, callback) {
    window.tronWeb.trx.getTransaction(hash).then(result => {
        if (!result.ret) {
            setTimeout(() => {
                checkTrxHash(hash, callback)
            }, 2000);
            return;
        }
        console.log('result.ret ------->', result);

        if (result.ret && result.ret[0]['contractRet'] === 'SUCCESS') {
            if(callback)
            {
                callback();
            }
            else {
                Toast.success(intl.get('CHAIN_HANDLE'))
            }
        } else {
            Toast.fail(intl.get('CONTRACT_FAIL'), 2)
        }
    }).catch(()=>{
        checkTrxHash(hash);
    });
}

export function getTrxApproveResult(res, callback) {
    console.log('result.ret ------->', res);
    window.tronWeb.trx.getTransaction(res).then(result => {
        if (!result.ret) {
            setTimeout(() => {
                getTrxApproveResult(res, callback)
            }, 2000);
            return;
        }

        console.log('result.ret ------->', result);

        if (result.ret && result.ret[0]['contractRet'] === 'SUCCESS') {
            callback();
        } else {
            Toast.fail(intl.get('APPROVE_FAIL'), 2)
        }
    }).catch(()=>{
        getTrxApproveResult(res, callback);
    })
}




