import React, { Component } from "react";

class Header extends Component {
    constructor(props) {
        super(props);

        this.state = {
        };
    }

    render() {
        const { title, goBack, transparent, right, rightText, onlyBack } = this.props;
        const style = {};
        if (transparent) style.backgroundColor = 'transparent';
        if (onlyBack) {
            style.height = '4vw';
            style.paddingTop = '4vw';
        }
        return (
            <React.Fragment>
                <div className="header" style={style}>
                    {
                        goBack ? <img src={require('../images/otc/back.png')} className={'back'} onClick={() => goBack()}/> : null
                    }
                    <div className={'title'}>{title ? title : ''}</div>
                    {
                        rightText ?
                        <div className={'right'} onClick={() => right()}>{rightText}</div>
                        : null
                    }
                </div>
            </React.Fragment>
        );
    }
}

export default Header;
