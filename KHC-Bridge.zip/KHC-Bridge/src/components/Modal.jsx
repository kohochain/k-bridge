import React, { Component } from "react";
import { Modal } from 'antd-mobile';

class AlertModal extends Component {

    render() {
        const { 
                visible,
                type, // @param: string, 左右按钮传'choose', 不传默认单按钮
                titleContent, //@param: array, 灰色字 
                btnText,    // 单按钮按钮文字
                leftBtnText, // 双按钮-左侧按钮文字
                rightBtnText, // 双按钮-右侧按钮文字
                onConfirm,  // 点击按钮确定
                onClickRight,
                onClickLeft,
                disabled, 
                isTextLeft,
                onClose,
            } = this.props;

        return (
            <Modal
                visible={visible}
                transparent
                maskClosable={true}
                onClose={onClose ? onClose : () => {}}
            >
                <div className={'modal'}>
                    {
                        titleContent.map((item,index) => {
                            return(
                                <div className={'modal-title'} key={index} style={{'whiteSpace': 'pre-wrap', textAlign: isTextLeft ? 'left' : 'center'}}>{item}</div>
                            )
                        })
                    }
                    {
                        type ?
                        <div className={'flex-between m-t-8'}>
                            <div className={'modal-btn-left m-r-3'} onClick={onClickLeft}>{leftBtnText}</div>
                            <div className={'modal-btn-right'} onClick={onClickRight}>{rightBtnText}</div>
                        </div>
                        :
                        <div className={disabled ? 'modal-btn-disable' : 'modal-btn-ok'} onClick={onConfirm}>{btnText}</div>
                    }
                </div>

            </Modal>
        );
    }
}

export default AlertModal;
