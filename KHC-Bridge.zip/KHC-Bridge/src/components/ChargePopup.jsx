import React, { Component } from "react";
import { Modal } from 'antd-mobile';
import Tabs from '../pages/Resonance/components/Tabs';

const imgs = {
    'sec': require('../images/sec.png'),
}
class ChargePopup extends Component {

    constructor(props) {
        super(props);
        this.state = {
            tab: 1,
            amount: '',
            pwd: '',
            fee: '',
        }
    }

    clickTab(index){
        this.setState({tab: index});
        this.props.changePopTabs();
    }

    renderCharge(){
        const { 
            onChange,
            onConfirm,
            chooseIcon,
            Icon,
            chargeAmount,
            chargeTotal,
            balance
        } = this.props;

        return(
            <div className={'p-l-5 p-r-5'}>
                <div className={'pop-title text-left m-t-8 m-b-3'}>选择您要充值的币种</div>
                <div className={'flex-between'}>
                    <div className={'pop-coin-btn'} onClick={() => chooseIcon('USDT')}>USDT
                        {
                            Icon === 'USDT' ?
                            <img src={imgs['sec']} alt=""/>
                            : null
                        }
                    </div>
                    <div className={'pop-coin-btn'} onClick={() => chooseIcon('MDC')}>MDC
                        {
                            Icon === 'MDC' ?
                            <img src={imgs['sec']} alt=""/>
                            : null
                        }
                    </div>
                </div>
                <div className={'flex-between m-t-8 m-b-3'}>
                    <div className={'pop-title text-left'}>当前已充值联动余额</div>
                    <div className={'pop-tips'}>{chargeTotal ? (Math.floor(chargeTotal * 10000) / 10000).toFixed(4) : '-'} {Icon}</div>
                </div>
                <div className={'pop-title text-left m-t-8 m-b-3'}>充值数量</div>
                <input
                    className={'pop-input'}
                    placeholder="请输入您要充值的数量"
                    type="text"
                    value={chargeAmount}
                    onChange={(value) => onChange(value.target.value, 0)} 
                />
                <div className={'pop-tips m-t-2 text-right'}>钱包可用余额：{balance[Icon.toLowerCase()] ? (Math.floor(balance[Icon.toLowerCase()] * 10000) / 10000).toFixed(4) : '-'} {Icon}</div>
                {
                    Icon === 'USDT' ? 
                    <div className={'pop-tips m-t-2 text-right'}>{(Math.floor(balance['mdc'] * 10000) / 10000).toFixed(4) + 'MDC'}</div>
                    : null
                }
            {/* 
                <div className={'pop-title text-left m-t-8 m-b-3'}>钱包密码</div>
                <input
                    className={'pop-input'}
                    placeholder="请输入钱包密码"
                    type="password"
                    value={chargePwd}
                    onChange={(value) => onChange(value.target.value, 1)} 
                /> */}
                <div className={'pop-btn m-t-8'} onClick={() => onConfirm(0)}>确认</div>
            </div>
        )
    }

    renderWithdraw(){
        const { 
            onChange,
            onConfirm,
            chooseIcon,
            Icon,
            chargeAmount,
            chargeTotal,
            balance
        } = this.props;
        return(
            <div className={'p-l-5 p-r-5'}>
                <div className={'pop-title text-left m-t-8 m-b-3'}>选择您要提现的币种</div>
                <div className={'flex-between'}>
                    <div className={'pop-coin-btn'} onClick={() => chooseIcon('USDT')}>USDT
                        {
                            Icon === 'USDT' ?
                            <img src={imgs['sec']} alt=""/>
                            : null
                        }
                    </div>
                    <div className={'pop-coin-btn'} onClick={() => chooseIcon('MDC')}>MDC
                        {
                            Icon === 'MDC' ?
                            <img src={imgs['sec']} alt=""/>
                            : null
                        }
                    </div>
                </div>
                <div className={'flex-between m-t-8 m-b-3'}>
                    <div className={'pop-title text-left'}>当前已充值联动余额</div>
                    <div className={'pop-tips'}>{chargeTotal >= 0 ? (Math.floor(chargeTotal * 10000) / 10000).toFixed(4) : '-'} {Icon}</div>
                </div>
                <div className={'pop-title text-left m-t-8 m-b-3'}>提现数量</div>
                <input
                    className={'pop-input'}
                    placeholder="请输入您要提现的数量" 
                    value={chargeAmount || ''}
                    onChange={(value) => onChange(value.target.value, 0)} 
                />
                {/* <div className={'pop-tips m-t-2 text-left'}>钱包可用余额：{balance[Icon.toLowerCase()] ? (Math.floor(balance[Icon.toLowerCase()] * 10000) / 10000).toFixed(4) : '-'} {Icon}</div> */}

                {/* <div className={'pop-title text-left m-t-8 m-b-3'}>钱包密码</div>
                <input
                    className={'pop-input'}
                    placeholder="请输入钱包密码"
                    type="password"
                    value={chargePwd || ''}
                    onChange={(value) => onChange(value.target.value, 1)} 
                /> */}
                <div className={'pop-title text-left m-t-8 m-b-3'}>合约服务费</div>
                <input
                    className={'pop-input'}
                    placeholder="请输入钱包密码"
                    value={Icon === 'USDT' ? '0.02' : '0.01'}
                    onChange={() => {}}
                />
                <div className={'pop-btn m-t-8'} onClick={() => onConfirm(1)}>确认</div>
            </div>
        )
    }

    render() {
        const { 
                visible,
                onClose,
            } = this.props;

        const { tab } = this.state;
        return (
            <Modal
                visible={visible}
                onClose={onClose}
                popup 
                animationType="slide-up"
            >
                <div className={'pop'}>
                    <div className={'flex-start p-l-5 p-r-5'}>
                        <div className={'pop-cancel'} onClick={onClose}>取消</div>
                        <div className={'flex-center width80 pop-tabs'}>
                            {/* <div onClick={() => this.clickTab(0)} className={tab === 0 ? 'active m-r-10' : 'm-r-10'}>充值</div> */}
                            <div onClick={() => this.clickTab(1)} className={tab ? 'active' : ''}>提现</div>
                        </div>
                        
                        {/* <div className={'pop-title text-center'}>安全验证1111</div> */}
                    </div>
                    <div className={'pop-line'}></div>
                    {tab === 0 ? this.renderCharge() : this.renderWithdraw()}
                </div>  
            </Modal>
        );
    }
}

export default ChargePopup;
